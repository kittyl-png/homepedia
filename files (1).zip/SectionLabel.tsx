import type { ReactNode } from "react";

type SectionLabelProps = {
  children: ReactNode;
};

export default function SectionLabel({ children }: SectionLabelProps) {
  return (
    <span className="text-xs font-bold text-brand-cyan uppercase tracking-[0.3em] mb-4 block">
      {children}
    </span>
  );
}

"use client";

import { useLocale } from "next-intl";
import { usePathname, useRouter } from "next/navigation";

export default function LanguageSwitcher() {
  const locale = useLocale();
  const pathname = usePathname();
  const router = useRouter();

  const switchLocale = () => {
    const nextLocale = locale === "en" ? "zh" : "en";
    // Replace /en/ or /zh/ prefix in the current path
    const newPath = pathname.replace(`/${locale}`, `/${nextLocale}`);
    router.push(newPath);
  };

  return (
    <button
      onClick={switchLocale}
      className="text-xs font-bold uppercase tracking-wider text-brand-blue hover:text-brand-cyan transition-colors"
    >
      {locale === "en" ? "中文" : "EN"}
    </button>
  );
}

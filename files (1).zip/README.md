# P1 — 骨架组件集成指南

## 产出文件

```
P1/
├── components/
│   ├── Logo.tsx              ← 1.3 品牌 Logo（渐变方块 H + 文字）
│   ├── SectionLabel.tsx      ← 1.3 Section 小标签（青色大写）
│   ├── CTAButton.tsx         ← 1.3 CTA 按钮（金色主要 + 深蓝次要）
│   ├── LanguageSwitcher.tsx  ← 1.1 语言切换（纯文字 EN/中文）
│   ├── Header.tsx            ← 1.1 全站导航（桌面 + 手机 + 滚动）
│   └── Footer.tsx            ← 1.2 全站底部
├── app/[locale]/layout.tsx   ← 更新：包裹 Header + main + Footer
└── animations.css            ← 追加到 globals.css 末尾的动画
```

## 安装依赖

```bash
npm install lucide-react
```

## 放置规则

1. `components/*.tsx` → 放入项目 `components/` 目录
2. `app/[locale]/layout.tsx` → 替换 P0.4 的版本（新增 Header/Footer 导入）
3. `animations.css` → 将内容**追加**到 `app/globals.css` 末尾

## 组件说明

### Logo (`components/Logo.tsx`)

| Prop | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `size` | `"default" \| "small"` | `"default"` | 小尺寸用于手机端 |
| `locale` | `string?` | — | 传入时 Logo 变为首页链接 |

```tsx
<Logo />                    // 纯展示
<Logo locale="en" />        // 点击跳转 /en
<Logo size="small" locale="en" />  // 手机端
```

### CTAButton (`components/CTAButton.tsx`)

| Prop | 类型 | 说明 |
|------|------|------|
| `variant` | `"primary" \| "secondary"` | 金色 / 深蓝 |
| `href` | `string?` | 有值时渲染为 Link/a |
| `external` | `boolean` | 外部链接（新窗口打开） |
| `fullWidth` | `boolean` | 全宽按钮 |

```tsx
// 金色主要 CTA → AI 助手
<CTAButton href="https://app.homepedia.com.au" external>
  Start with AI Assistant
</CTAButton>

// 深蓝次要 CTA
<CTAButton variant="secondary" href="/en/contact">
  Contact Us
</CTAButton>

// 全宽表单提交按钮
<CTAButton variant="secondary" fullWidth type="submit">
  Send Message
</CTAButton>
```

### SectionLabel (`components/SectionLabel.tsx`)

```tsx
<SectionLabel>Our Expertise</SectionLabel>
<h2 className="text-3xl md:text-4xl font-bold text-brand-blue">
  Core Capabilities
</h2>
```

### Header (`components/Header.tsx`)

- **桌面端**: Logo | Home Services Insights AI Advisor | ── | [Contact] 中文
- **滚动 > 20px**: `bg-white/95 backdrop-blur-xl shadow-sm border-b border-slate-100`
- **手机端**: Logo + ☰ → 展开 2×2 网格面板
  - Home (LayoutGrid) | Pricing (DollarSign)
  - Blog (BookOpen) | AI Assistant (MessageSquare, 深色背景)
  - 语言切换（纯文字居中）
  - 全宽 Contact 按钮
- Contact 按钮在 `/contact` 页变金色，其余页面深蓝
- 展开动画: `slide-in-from-top`
- 打开菜单时锁定 body scroll

### Footer (`components/Footer.tsx`)

- `bg-slate-50 border-t border-slate-200`
- 三区域: 品牌描述 | Compliance (Privacy Act / AML/CTF) | Contact (Sydney / email)
- 底部: © + ABN + TPB | 免责声明 (italic)
- 所有文案从 `messages/[locale].json` 的 `footer` namespace 读取

### LanguageSwitcher (`components/LanguageSwitcher.tsx`)

- 纯文字按钮 `EN` / `中文`
- 点击后通过 next-intl 路由切换 locale（替换 URL 前缀）

## layout.tsx 变更

相比 P0.4 的版本，新增：
```tsx
import Header from "@/components/Header";
import Footer from "@/components/Footer";

// 在 NextIntlClientProvider 内部：
<Header />
<main>{children}</main>
<Footer />
```

所有子页面自动被 Header + Footer 包裹。

## 验证清单

- [ ] `npm run dev` 无报错
- [ ] 访问 `/en` — 看到 Header（Logo + 导航 + Contact 按钮 + 中文切换）
- [ ] 滚动页面 — Header 背景变为磨砂白 + 阴影 + 底边线
- [ ] 缩小浏览器到 < 768px — 导航变为 ☰ 按钮
- [ ] 点击 ☰ — 展开 2×2 网格面板（从顶部滑入）
- [ ] AI Assistant 格子是深色背景 `#001b3d`
- [ ] 语言切换 — 点击后 URL 从 `/en` 变为 `/zh`，页面内容切换
- [ ] Footer 可见 — 背景 slate-50，两列信息，底部免责声明 italic
- [ ] Contact 按钮点击 — 跳转 `/en/contact`（或 `/zh/contact`）
- [ ] AI Assistant 链接 — 新窗口打开 app.homepedia.com.au

# P3 — 核心内容页集成指南

## 产出文件

```
P3/
├── app/[locale]/
│   ├── services/page.tsx      ← 3.1 服务详情页
│   ├── pricing/page.tsx       ← 3.2 完整定价页
│   ├── about/page.tsx         ← 3.3 关于我们
│   ├── contact/page.tsx       ← 3.4 联系我们
│   └── faq/page.tsx           ← 3.7 FAQ
├── components/
│   ├── ContactForm.tsx        ← 联系表单（客户端组件）
│   └── FAQAccordion.tsx       ← 折叠面板（客户端组件）
└── messages/
    ├── en.json                ← 替换 P2 版本（新增 P3 namespace）
    └── zh.json                ← 替换 P2 版本（新增 P3 namespace）
```

## 放置规则

1. `app/[locale]/{services,pricing,about,contact,faq}/page.tsx` → 直接放入对应目录
2. `components/ContactForm.tsx` + `FAQAccordion.tsx` → 放入 `components/`
3. `messages/en.json` / `zh.json` → **替换** P2 版本（已包含 P0-P2-P3 全部内容）

## 各页面说明

### 3.1 Services (`/services`)
- Hero（暖白）→ 三大服务区块交替（白/暖白/白）→ 深蓝底部 CTA
- 每块服务：左侧文案+CTA / 右侧 feature checklist 卡片
- 奇数行左右翻转（`md:order-2`）
- Lucide 图标：Shield / BarChart3 / Globe

### 3.2 Pricing (`/pricing`)
- Hero（暖白）→ 深蓝 base 大卡片（白底区）→ 4 类 addon 双列 grid（暖白区）→ 专项服务列表（白底区）
- 价格数据目前从翻译文件读取，后续可改为读 `lib/pricing.json`

### 3.3 About (`/about`)
- Hero（暖白）→ 故事双卡片（白底区）→ 资质三卡片（暖白区）→ 团队双卡片（白底区）→ 深蓝 CTA
- 团队照片为占位符，待替换

### 3.4 Contact (`/contact`)
- Hero（暖白）→ 左右双栏（白底区）：左侧联系信息 + AI 助手提示卡 / 右侧表单
- `ContactForm.tsx` 为客户端组件，提交到 `/api/enquiry`
- 表单状态：idle → sending → sent（成功页）/ error
- **注意**：`/api/enquiry/route.ts` 后端需在 P3.5 中实现（Google Sheets API）

### 3.7 FAQ (`/faq`)
- Hero（暖白）→ 分类折叠面板（白底区）→ 暖白底部 CTA
- `FAQAccordion.tsx` 为客户端组件，点击展开/收起
- 3 个分类：Tax Returns / Pricing & Payment / AI Assistant
- 支持 FAQPage JSON-LD（待后续 SEO 优化中添加）

## 翻译结构变更

相比 P2 的 messages，新增以下 namespace：

| Namespace | 页面 |
|-----------|------|
| `servicesPage` | 3.1 服务详情 |
| `pricingPage` | 3.2 完整定价 |
| `aboutPage` | 3.3 关于我们 |
| `contactPage` | 3.4 联系我们（含 `form` 子对象） |
| `faqPage` | 3.7 FAQ（含 3 个分类） |

## 待实现

- [ ] 3.5 `/api/enquiry/route.ts` — Google Sheets API 写入
- [ ] 3.6 `/privacy` + `/terms` — 法律文本迁移
- [ ] FAQ JSON-LD 结构化数据
- [ ] About 页团队真实照片

## 验证清单

- [ ] 5 个页面均可通过 `/en/services` 等路由访问
- [ ] 每个页面背景色为暖白/白交替，仅一个深蓝强调区
- [ ] Contact 表单可输入、Select 可选择（提交功能需 API）
- [ ] FAQ 折叠面板点击可展开/收起
- [ ] 语言切换后所有文案变为中文
- [ ] 移动端响应式正常（grid 变单列）

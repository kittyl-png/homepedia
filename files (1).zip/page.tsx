import { setRequestLocale } from "next-intl/server";
import { useTranslations } from "next-intl";
import { Shield, BarChart3, Globe } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";
import CTAButton from "@/components/CTAButton";

const AI_URL = "https://app.homepedia.com.au";

const icons = [
  <Shield key="s" size={28} className="text-brand-blue" />,
  <BarChart3 key="b" size={28} className="text-brand-blue" />,
  <Globe key="g" size={28} className="text-brand-blue" />,
];

type Props = { params: Promise<{ locale: string }> };

export default async function ServicesPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <ServicesContent />;
}

function ServicesContent() {
  const t = useTranslations("servicesPage");
  const keys = ["individual", "business", "cfo"] as const;

  return (
    <div>
      {/* Hero */}
      <div className="bg-warm-white pt-32 pb-20 px-6 text-center">
        <SectionLabel>{t("label")}</SectionLabel>
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h1>
        <p className="text-slate-500 text-base max-w-lg mx-auto">{t("subtitle")}</p>
      </div>

      {/* Service blocks — alternating warm/white */}
      {keys.map((key, i) => {
        const isEven = i % 2 === 0;
        const features: string[] = [];
        for (let j = 0; j < 6; j++) {
          try { features.push(t(`${key}.features.${j}`)); } catch { break; }
        }

        return (
          <section key={key} className={isEven ? "bg-white" : "bg-warm-white"}>
            <div className="max-w-5xl mx-auto px-6 py-20">
              <div className={`grid md:grid-cols-2 gap-12 items-center ${i % 2 === 1 ? "md:direction-rtl" : ""}`}>
                {/* Text */}
                <div className={i % 2 === 1 ? "md:order-2" : ""}>
                  <div className="mb-5">{icons[i]}</div>
                  <h2 className="text-3xl font-heading font-bold text-brand-blue mb-4">{t(`${key}.title`)}</h2>
                  <p className="text-slate-500 leading-relaxed text-sm mb-7">{t(`${key}.desc`)}</p>
                  <CTAButton href={AI_URL} external>{i === 2 ? t("ctaTalk") : t("ctaQuote")}</CTAButton>
                </div>
                {/* Features card */}
                <div className={`${isEven ? "bg-warm-white" : "bg-white"} p-8 rounded-2xl border border-slate-100 ${i % 2 === 1 ? "md:order-1" : ""}`}>
                  <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400 mb-4">{t("included")}</p>
                  {features.map((f, j) => (
                    <div key={j} className={`flex items-center gap-3 py-3 ${j < features.length - 1 ? "border-b border-slate-100" : ""}`}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#5de0e6" strokeWidth="2.5"><path d="M20 6L9 17l-5-5" /></svg>
                      <span className="text-sm text-brand-blue">{f}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        );
      })}

      {/* Bottom CTA — blue */}
      <section className="bg-brand-blue py-20 px-6 text-center">
        <h2 className="text-3xl font-heading font-bold text-white mb-4">{t("bottomTitle")}</h2>
        <p className="text-white/60 mb-8">{t("bottomSubtitle")}</p>
        <CTAButton href={AI_URL} external>{t("bottomCta")}</CTAButton>
      </section>
    </div>
  );
}

import { useTranslations } from "next-intl";
import Logo from "./Logo";

export default function Footer() {
  const t = useTranslations("footer");
  const year = new Date().getFullYear();

  return (
    <footer className="py-16 px-6 border-t border-slate-200 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        {/* Top section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-start gap-10 mb-12">
          {/* Brand column */}
          <div className="max-w-xs">
            <div className="mb-4">
              <Logo />
            </div>
            <p className="text-sm text-slate-500 leading-relaxed">
              {t("tagline")}
            </p>
          </div>

          {/* Right columns */}
          <div className="flex gap-12">
            {/* Compliance */}
            <div className="space-y-4">
              <h4 className="font-bold text-brand-blue uppercase tracking-widest text-xs">
                {t("compliance")}
              </h4>
              <ul className="text-sm text-slate-500 space-y-2">
                <li>{t("privacyAct")}</li>
                <li>{t("amlCtf")}</li>
              </ul>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h4 className="font-bold text-brand-blue uppercase tracking-widest text-xs">
                {t("contactTitle")}
              </h4>
              <ul className="text-sm text-slate-500 space-y-2">
                <li>{t("location")}</li>
                <li>{t("email")}</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Divider + bottom */}
        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between gap-4 text-xs text-slate-400 font-medium tracking-wide">
          <p>
            {t("copyright", { year })} · {t("abn")} · {t("tpb")}
          </p>
          <p className="max-w-md md:text-right italic">
            {t("disclaimer")}
          </p>
        </div>
      </div>
    </footer>
  );
}

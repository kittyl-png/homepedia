import Link from "next/link";

type LogoProps = {
  size?: "default" | "small";
  /** When used inside Header, locale is needed for the home link */
  locale?: string;
};

export default function Logo({ size = "default", locale }: LogoProps) {
  const isSmall = size === "small";
  const iconSize = isSmall ? "w-7 h-7" : "w-8 h-8";
  const textSize = isSmall ? "text-lg" : "text-2xl";
  const iconFont = isSmall ? "text-sm" : "text-lg";

  const content = (
    <span className="flex items-center gap-2 group">
      {/* Gradient square "H" */}
      <span
        className={`${iconSize} rounded-lg flex items-center justify-center text-white font-bold ${iconFont} shadow-logo`}
        style={{ background: "var(--gradient-brand)" }}
      >
        H
      </span>
      <span
        className={`${textSize} font-bold tracking-tight text-brand-blue`}
      >
        Homepedia
      </span>
    </span>
  );

  if (locale) {
    return (
      <Link href={`/${locale}`} className="no-underline">
        {content}
      </Link>
    );
  }

  return content;
}

"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

type FAQItem = { question: string; answer: string };
type FAQCategory = { title: string; items: FAQItem[] };

export default function FAQAccordion({ categories }: { categories: FAQCategory[] }) {
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  let globalIdx = 0;

  return (
    <div className="space-y-11">
      {categories.map((cat, ci) => (
        <div key={ci}>
          <h2 className="text-xl font-heading font-bold text-brand-blue mb-4 pb-3 border-b-2 border-slate-100">
            {cat.title}
          </h2>
          <div className="space-y-2">
            {cat.items.map((item) => {
              const idx = globalIdx++;
              const isOpen = openIdx === idx;
              return (
                <div key={idx} className={`rounded-2xl border border-slate-100 overflow-hidden transition-colors ${isOpen ? "bg-warm-white" : "bg-white"}`}>
                  <button
                    onClick={() => setOpenIdx(isOpen ? null : idx)}
                    className="w-full flex justify-between items-center px-5 py-4 text-left"
                  >
                    <span className="text-sm font-semibold text-brand-blue pr-3">{item.question}</span>
                    <ChevronDown
                      size={18}
                      className={`text-brand-cyan shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-4">
                      <p className="text-sm text-slate-500 leading-relaxed">{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

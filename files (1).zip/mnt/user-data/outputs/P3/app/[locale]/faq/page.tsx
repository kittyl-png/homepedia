import { setRequestLocale } from "next-intl/server";
import { useTranslations, useLocale } from "next-intl";
import Link from "next/link";
import SectionLabel from "@/components/SectionLabel";
import CTAButton from "@/components/CTAButton";
import FAQAccordion from "@/components/FAQAccordion";

type Props = { params: Promise<{ locale: string }> };

export default async function FAQPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <FAQContent />;
}

function FAQContent() {
  const t = useTranslations("faqPage");
  const locale = useLocale();

  // Build categories from translations
  const catKeys = ["taxReturns", "pricing", "ai"] as const;
  const categories = catKeys.map((key) => {
    const items: { question: string; answer: string }[] = [];
    for (let j = 0; j < 5; j++) {
      try {
        items.push({
          question: t(`${key}.items.${j}.q`),
          answer: t(`${key}.items.${j}.a`),
        });
      } catch { break; }
    }
    return { title: t(`${key}.title`), items };
  });

  return (
    <div>
      {/* Hero */}
      <div className="bg-warm-white pt-32 pb-20 px-6 text-center">
        <SectionLabel>{t("label")}</SectionLabel>
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h1>
        <p className="text-slate-500 text-base">{t("subtitle")}</p>
      </div>

      {/* FAQ list */}
      <section className="bg-white px-6 py-16 pb-24">
        <div className="max-w-3xl mx-auto">
          <FAQAccordion categories={categories} />

          {/* Bottom CTA */}
          <div className="bg-warm-white p-10 rounded-2xl text-center mt-12">
            <h3 className="text-2xl font-heading font-bold text-brand-blue mb-3">{t("bottomTitle")}</h3>
            <p className="text-sm text-slate-500 mb-5">{t("bottomSubtitle")}</p>
            <CTAButton variant="secondary" href={`/${locale}/contact`}>{t("bottomCta")}</CTAButton>
          </div>
        </div>
      </section>
    </div>
  );
}

import { setRequestLocale } from "next-intl/server";
import { useTranslations, useLocale } from "next-intl";
import { Shield, FileText, Lock } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";
import CTAButton from "@/components/CTAButton";

const credIcons = [
  <Shield key="s" size={24} className="text-brand-blue" />,
  <FileText key="f" size={24} className="text-brand-blue" />,
  <Lock key="l" size={24} className="text-brand-blue" />,
];

type Props = { params: Promise<{ locale: string }> };

export default async function AboutPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <AboutContent />;
}

function AboutContent() {
  const t = useTranslations("aboutPage");
  const locale = useLocale();

  return (
    <div>
      {/* Hero */}
      <div className="bg-warm-white pt-32 pb-20 px-6 text-center">
        <SectionLabel>{t("label")}</SectionLabel>
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h1>
        <p className="text-slate-500 text-base max-w-lg mx-auto">{t("subtitle")}</p>
      </div>

      {/* Story — white */}
      <section className="bg-white px-6 py-20">
        <div className="max-w-4xl mx-auto">
          <SectionLabel>{t("storyLabel")}</SectionLabel>
          <h2 className="text-3xl font-heading font-bold text-brand-blue mb-8">{t("storyTitle")}</h2>
          <div className="grid md:grid-cols-2 gap-5">
            <div className="bg-warm-white p-7 rounded-2xl">
              <p className="text-slate-500 leading-relaxed text-sm">{t("storyLeft")}</p>
            </div>
            <div className="bg-warm-white p-7 rounded-2xl">
              <p className="text-slate-500 leading-relaxed text-sm">{t("storyRight")}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Credentials — warm */}
      <section className="bg-warm-white px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <SectionLabel>{t("credLabel")}</SectionLabel>
          <h2 className="text-3xl font-heading font-bold text-brand-blue mb-8">{t("credTitle")}</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="bg-white p-7 rounded-2xl border border-slate-100 text-center">
                <div className="mb-4">{credIcons[i]}</div>
                <h3 className="text-sm font-bold text-brand-blue mb-2">{t(`creds.${i}.title`)}</h3>
                <p className="text-xs text-slate-500">{t(`creds.${i}.desc`)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team — white */}
      <section className="bg-white px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <SectionLabel>{t("teamLabel")}</SectionLabel>
          <h2 className="text-3xl font-heading font-bold text-brand-blue mb-8">{t("teamTitle")}</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {[0, 1].map((i) => (
              <div key={i} className="bg-warm-white p-7 rounded-2xl flex gap-5 items-center text-left">
                <div className="w-[72px] h-[72px] rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-slate-400 text-[10px] font-bold uppercase shrink-0">
                  Photo
                </div>
                <div>
                  <h3 className="text-lg font-bold text-brand-blue">{t(`team.${i}.name`)}</h3>
                  <p className="text-sm text-slate-500">{t(`team.${i}.role`)}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 italic mt-4">{t("teamNote")}</p>
        </div>
      </section>

      {/* CTA — blue */}
      <section className="bg-brand-blue py-20 px-6 text-center">
        <h2 className="text-3xl font-heading font-bold text-white mb-4">{t("ctaTitle")}</h2>
        <p className="text-white/60 mb-8">{t("ctaSubtitle")}</p>
        <CTAButton href={`/${locale}/contact`}>{t("ctaButton")}</CTAButton>
      </section>
    </div>
  );
}

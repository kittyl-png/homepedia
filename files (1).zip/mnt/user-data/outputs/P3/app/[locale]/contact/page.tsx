import { setRequestLocale } from "next-intl/server";
import { useTranslations } from "next-intl";
import { MapPin, Mail, Clock } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";
import ContactForm from "@/components/ContactForm";

const AI_URL = "https://app.homepedia.com.au";

const infoIcons = [
  <MapPin key="m" size={18} className="text-brand-blue" />,
  <Mail key="e" size={18} className="text-brand-blue" />,
  <Clock key="c" size={18} className="text-brand-blue" />,
];

type Props = { params: Promise<{ locale: string }> };

export default async function ContactPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <ContactContent />;
}

function ContactContent() {
  const t = useTranslations("contactPage");

  return (
    <div>
      {/* Hero */}
      <div className="bg-warm-white pt-32 pb-20 px-6 text-center">
        <SectionLabel>{t("label")}</SectionLabel>
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h1>
        <p className="text-slate-500 text-base">{t("subtitle")}</p>
      </div>

      {/* Content */}
      <section className="bg-white px-6 py-20">
        <div className="max-w-5xl mx-auto grid md:grid-cols-[1fr_1.2fr] gap-12 items-start">
          {/* Left — info */}
          <div>
            <h2 className="text-2xl font-heading font-bold text-brand-blue mb-7">{t("infoTitle")}</h2>
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex gap-4 mb-5 items-center">
                <div className="w-11 h-11 rounded-xl bg-warm-white flex items-center justify-center shrink-0">
                  {infoIcons[i]}
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400 mb-0.5">{t(`info.${i}.label`)}</p>
                  <p className="text-sm font-semibold text-brand-blue">{t(`info.${i}.value`)}</p>
                </div>
              </div>
            ))}

            {/* AI tip card */}
            <div className="bg-warm-white p-6 rounded-2xl mt-6">
              <p className="text-sm font-semibold text-brand-blue mb-1">{t("aiTipTitle")}</p>
              <p className="text-xs text-slate-500 mb-4 leading-relaxed">{t("aiTipDesc")}</p>
              <a href={AI_URL} target="_blank" rel="noopener noreferrer"
                className="inline-block bg-brand-blue text-white font-bold text-xs px-5 py-2.5 rounded-lg hover:bg-brand-cyan transition-colors">
                {t("aiTipCta")}
              </a>
            </div>
          </div>

          {/* Right — form */}
          <ContactForm />
        </div>
      </section>
    </div>
  );
}

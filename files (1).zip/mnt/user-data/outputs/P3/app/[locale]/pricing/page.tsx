import { setRequestLocale } from "next-intl/server";
import { useTranslations, useLocale } from "next-intl";
import SectionLabel from "@/components/SectionLabel";
import CTAButton from "@/components/CTAButton";

const AI_URL = "https://app.homepedia.com.au";

type Props = { params: Promise<{ locale: string }> };

export default async function PricingPage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <PricingContent />;
}

function PricingContent() {
  const t = useTranslations("pricingPage");
  const addonCats = ["property", "investments", "business", "employment"] as const;

  return (
    <div>
      {/* Hero */}
      <div className="bg-warm-white pt-32 pb-20 px-6 text-center">
        <SectionLabel>{t("label")}</SectionLabel>
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h1>
        <p className="text-slate-500 text-base max-w-md mx-auto">{t("subtitle")}</p>
      </div>

      {/* Base — blue card */}
      <section className="bg-white px-6 py-16">
        <div className="max-w-3xl mx-auto bg-brand-blue p-10 md:p-12 rounded-3xl text-white flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <span className="bg-brand-gold text-brand-blue text-[10px] font-bold px-3 py-1 rounded-md uppercase">{t("baseTag")}</span>
            <h2 className="text-2xl font-bold mt-4 mb-2">{t("baseTitle")}</h2>
            <p className="text-white/60 text-sm max-w-sm">{t("baseIncludes")}</p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/50 mb-1">{t("from")}</p>
            <p className="text-5xl font-bold">$220</p>
          </div>
        </div>
      </section>

      {/* Add-ons — warm */}
      <section className="bg-warm-white px-6 py-20">
        <div className="max-w-3xl mx-auto">
          <h3 className="text-2xl font-heading font-bold text-brand-blue mb-8">{t("addonsTitle")}</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {addonCats.map((cat) => {
              const items: { label: string; price: string }[] = [];
              for (let j = 0; j < 5; j++) {
                try {
                  items.push({
                    label: t(`addons.${cat}.${j}.label`),
                    price: t(`addons.${cat}.${j}.price`),
                  });
                } catch { break; }
              }
              return (
                <div key={cat} className="bg-white p-7 rounded-2xl border border-slate-100">
                  <p className="text-[10px] font-bold text-brand-cyan uppercase tracking-[0.15em] mb-4">{t(`addons.${cat}.catName`)}</p>
                  {items.map((item, ii) => (
                    <div key={ii} className={`flex justify-between py-2.5 ${ii < items.length - 1 ? "border-b border-warm-white" : ""}`}>
                      <span className="text-sm text-slate-600">{item.label}</span>
                      <span className="text-sm font-bold text-brand-blue">{item.price}</span>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Specialist — white */}
      <section className="bg-white px-6 py-20">
        <div className="max-w-3xl mx-auto">
          <h3 className="text-2xl font-heading font-bold text-brand-blue mb-6">{t("specialistTitle")}</h3>
          <div className="bg-warm-white p-7 rounded-2xl">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className={`flex justify-between py-4 ${i < 3 ? "border-b border-slate-100" : ""}`}>
                <span className="text-sm font-semibold text-brand-blue">{t(`specialist.${i}.label`)}</span>
                <span className="text-sm font-bold text-brand-blue">{t(`specialist.${i}.price`)}</span>
              </div>
            ))}
          </div>
          <p className="text-sm text-slate-500 mt-6">
            💡 <strong className="text-brand-blue">{t("tipBold")}</strong> {t("tipRest")}
          </p>
          <div className="text-center mt-7">
            <CTAButton href={AI_URL} external>{t("cta")}</CTAButton>
          </div>
        </div>
      </section>
    </div>
  );
}

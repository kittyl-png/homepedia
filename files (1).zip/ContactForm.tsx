"use client";

import { useState, type FormEvent } from "react";
import { useTranslations } from "next-intl";

export default function ContactForm() {
  const t = useTranslations("contactPage.form");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus("sending");

    const form = e.currentTarget;
    const data = {
      name: (form.elements.namedItem("name") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
      phone: (form.elements.namedItem("phone") as HTMLInputElement).value,
      service: (form.elements.namedItem("service") as HTMLSelectElement).value,
      message: (form.elements.namedItem("message") as HTMLTextAreaElement).value,
    };

    try {
      const res = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error();
      setStatus("sent");
      form.reset();
    } catch {
      setStatus("error");
    }
  };

  if (status === "sent") {
    return (
      <div className="bg-warm-white p-10 rounded-3xl text-center">
        <div className="text-4xl mb-4">✓</div>
        <h3 className="text-xl font-heading font-bold text-brand-blue mb-2">{t("successTitle")}</h3>
        <p className="text-sm text-slate-500">{t("successDesc")}</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-warm-white p-10 rounded-3xl space-y-5">
      <Field label={t("nameLabel")} name="name" placeholder={t("namePh")} required />
      <Field label={t("emailLabel")} name="email" type="email" placeholder={t("emailPh")} required />
      <Field label={t("phoneLabel")} name="phone" type="tel" placeholder={t("phonePh")} />

      <div>
        <label className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400 block mb-1.5">{t("serviceLabel")}</label>
        <select name="service" className="w-full bg-white border border-slate-200 p-3.5 rounded-xl text-sm outline-none text-slate-400">
          <option value="">{t("servicePh")}</option>
          <option value="individual">{t("serviceOpt1")}</option>
          <option value="business">{t("serviceOpt2")}</option>
          <option value="cfo">{t("serviceOpt3")}</option>
          <option value="other">{t("serviceOpt4")}</option>
        </select>
      </div>

      <div>
        <label className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400 block mb-1.5">{t("messageLabel")}</label>
        <textarea name="message" rows={5} className="w-full bg-white border border-slate-200 p-3.5 rounded-xl text-sm outline-none resize-y" placeholder={t("messagePh")} required />
      </div>

      <button type="submit" disabled={status === "sending"}
        className="w-full bg-brand-gold hover:bg-brand-gold-hover text-brand-blue font-bold py-4 rounded-xl shadow-cta transition-all disabled:opacity-60">
        {status === "sending" ? t("sending") : t("submit")}
      </button>

      {status === "error" && (
        <p className="text-xs text-red-500 text-center">{t("error")}</p>
      )}
    </form>
  );
}

function Field({ label, name, type = "text", placeholder, required = false }: {
  label: string; name: string; type?: string; placeholder: string; required?: boolean;
}) {
  return (
    <div>
      <label className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400 block mb-1.5">{label}</label>
      <input name={name} type={type} placeholder={placeholder} required={required}
        className="w-full bg-white border border-slate-200 p-3.5 rounded-xl text-sm outline-none" />
    </div>
  );
}

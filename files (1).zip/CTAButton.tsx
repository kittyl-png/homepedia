import Link from "next/link";
import type { ReactNode } from "react";

type CTAButtonProps = {
  children: ReactNode;
  variant?: "primary" | "secondary";
  href?: string;
  /** Open in new tab (for external links like app.homepedia.com.au) */
  external?: boolean;
  fullWidth?: boolean;
  onClick?: () => void;
  type?: "button" | "submit";
};

const styles = {
  primary:
    "bg-brand-gold hover:bg-brand-gold-hover text-brand-blue font-bold py-4 px-10 rounded-xl shadow-cta hover:scale-[1.02] active:scale-95 transition-all text-base",
  secondary:
    "bg-brand-blue hover:bg-brand-cyan text-white font-bold py-5 px-10 rounded-xl uppercase text-xs tracking-widest transition-colors",
} as const;

export default function CTAButton({
  children,
  variant = "primary",
  href,
  external = false,
  fullWidth = false,
  onClick,
  type = "button",
}: CTAButtonProps) {
  const className = `${styles[variant]} inline-flex items-center justify-center gap-3${fullWidth ? " w-full" : ""}`;

  if (href) {
    if (external) {
      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className={className}
        >
          {children}
        </a>
      );
    }
    return (
      <Link href={href} className={className}>
        {children}
      </Link>
    );
  }

  return (
    <button type={type} onClick={onClick} className={className}>
      {children}
    </button>
  );
}

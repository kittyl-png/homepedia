"use client";

import { useState, useEffect } from "react";
import { useTranslations, useLocale } from "next-intl";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Menu,
  X,
  LayoutGrid,
  DollarSign,
  BookOpen,
  MessageSquare,
} from "lucide-react";
import Logo from "./Logo";
import LanguageSwitcher from "./LanguageSwitcher";

const AI_ASSISTANT_URL = "https://app.homepedia.com.au";

export default function Header() {
  const t = useTranslations("nav");
  const locale = useLocale();
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Scroll detection
  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  const isHome = pathname === `/${locale}` || pathname === `/${locale}/`;

  // Desktop nav links
  const navLinks = [
    { label: t("home"), href: `/${locale}` },
    { label: t("services"), href: `/${locale}/services` },
    { label: t("blog"), href: `/${locale}/blog` },
    { label: t("assistant"), href: AI_ASSISTANT_URL, external: true },
  ];

  // Mobile grid items
  const mobileGrid = [
    { icon: <LayoutGrid size={24} />, label: t("home"), href: `/${locale}`, dark: false },
    { icon: <DollarSign size={24} />, label: t("pricing"), href: `/${locale}/pricing`, dark: false },
    { icon: <BookOpen size={24} />, label: t("blog"), href: `/${locale}/blog`, dark: false },
    { icon: <MessageSquare size={24} className="text-brand-cyan" />, label: t("assistant"), href: AI_ASSISTANT_URL, dark: true, external: true },
  ];

  const isActive = (href: string) => {
    if (href === `/${locale}` || href === `/${locale}/`) return isHome;
    return pathname.startsWith(href);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4 ${
        isScrolled || !isHome
          ? "bg-white/95 backdrop-blur-xl shadow-sm border-b border-slate-100"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <Logo locale={locale} />

        {/* ─── Desktop Nav ─── */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) =>
            link.external ? (
              <a
                key={link.href}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-brand-blue transition-colors flex items-center gap-1.5"
              >
                <MessageSquare size={14} />
                {link.label}
              </a>
            ) : (
              <Link
                key={link.href}
                href={link.href}
                className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${
                  isActive(link.href)
                    ? "text-brand-blue"
                    : "text-slate-400 hover:text-brand-blue"
                }`}
              >
                {link.label}
              </Link>
            )
          )}

          {/* Divider */}
          <div className="h-6 w-px bg-slate-100" />

          {/* Contact button */}
          <Link
            href={`/${locale}/contact`}
            className={`px-6 py-2 rounded-lg font-bold uppercase text-[10px] tracking-widest transition-all ${
              pathname.startsWith(`/${locale}/contact`)
                ? "bg-brand-gold text-brand-blue"
                : "bg-brand-blue text-white hover:bg-brand-cyan"
            }`}
          >
            {t("contact")}
          </Link>

          {/* Language switch */}
          <LanguageSwitcher />
        </nav>

        {/* ─── Mobile Hamburger ─── */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="md:hidden text-brand-blue"
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* ─── Mobile Panel ─── */}
      {mobileOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-b border-slate-100 p-6 md:hidden animate-in slide-in-from-top duration-200">
          {/* 2×2 Grid */}
          <div className="grid grid-cols-2 gap-3">
            {mobileGrid.map((item) => {
              const inner = (
                <div
                  className={`p-6 rounded-2xl flex flex-col items-center gap-2 font-bold transition-colors ${
                    item.dark
                      ? "bg-[#001b3d] text-brand-cyan"
                      : "bg-slate-50 text-brand-blue"
                  }`}
                >
                  {item.icon}
                  <span className="text-sm">{item.label}</span>
                </div>
              );

              if (item.external) {
                return (
                  <a
                    key={item.href}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setMobileOpen(false)}
                  >
                    {inner}
                  </a>
                );
              }
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                >
                  {inner}
                </Link>
              );
            })}
          </div>

          {/* Language switch — centered below grid */}
          <div className="text-center py-3">
            <LanguageSwitcher />
          </div>

          {/* Full-width Contact CTA */}
          <Link
            href={`/${locale}/contact`}
            onClick={() => setMobileOpen(false)}
            className="w-full block bg-brand-blue text-white py-5 rounded-2xl font-bold uppercase tracking-widest text-center text-xs transition-colors hover:bg-brand-cyan"
          >
            {t("contact")}
          </Link>
        </div>
      )}
    </header>
  );
}

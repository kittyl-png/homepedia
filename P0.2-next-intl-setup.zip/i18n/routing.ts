import { defineRouting } from "next-intl/routing";

export const routing = defineRouting({
  locales: ["en", "zh"],
  defaultLocale: "en",
  // URL: /en/about, /zh/about
  // 根路径 / 重定向到 /en
  localePrefix: "always",
});

export type Locale = (typeof routing.locales)[number];

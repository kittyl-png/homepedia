import { createNavigation } from "next-intl/navigation";
import { routing } from "./routing";

// 导出带有 locale 感知的 Link, redirect, usePathname, useRouter
export const { Link, redirect, usePathname, useRouter } =
  createNavigation(routing);

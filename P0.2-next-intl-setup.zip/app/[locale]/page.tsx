import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";

export default function HomePage() {
  const t = useTranslations();

  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-8 p-6">
      <h1 className="text-4xl font-bold">{t("hero.title")}</h1>
      <p className="text-lg text-gray-500">{t("hero.subtitle")}</p>
      <div className="flex gap-4">
        <Link href="/" locale="en" className="px-4 py-2 bg-blue-600 text-white rounded">
          English
        </Link>
        <Link href="/" locale="zh" className="px-4 py-2 bg-blue-600 text-white rounded">
          中文
        </Link>
      </div>
      <p className="text-sm text-gray-400">{t("footer.tpb")}</p>
    </main>
  );
}

import { useTranslations, useLocale } from "next-intl";
import SectionLabel from "@/components/SectionLabel";
import CTAButton from "@/components/CTAButton";

const AI_URL = "https://app.homepedia.com.au";

export default function BottomCTA() {
  const t = useTranslations("bottomCta");
  const locale = useLocale();

  return (
    <section className="py-24 px-6 bg-white text-center">
      <div className="max-w-xl mx-auto">
        <SectionLabel>{t("label")}</SectionLabel>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-blue mb-4">
          {t("title")}
        </h2>
        <p className="text-slate-500 mb-10 text-base leading-relaxed">
          {t("subtitle")}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <CTAButton href={AI_URL} external>
            {t("ctaPrimary")}
          </CTAButton>
          <CTAButton variant="secondary" href={`/${locale}/contact`}>
            {t("ctaSecondary")}
          </CTAButton>
        </div>
      </div>
    </section>
  );
}

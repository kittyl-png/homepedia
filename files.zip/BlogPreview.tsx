"use client";

import { useState } from "react";
import { useTranslations, useLocale } from "next-intl";
import Link from "next/link";
import { Clock, ArrowRight, User, X, Share2 } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";

const AI_URL = "https://app.homepedia.com.au";

type Article = {
  category: string;
  title: string;
  excerpt: string;
  content: string;
  readTime: string;
  author: string;
  date: string;
};

export default function BlogPreview() {
  const t = useTranslations("blogPreview");
  const locale = useLocale();
  const [selected, setSelected] = useState<Article | null>(null);

  // Hardcoded articles — will be replaced with dynamic data in P4
  const articles: Article[] = [
    {
      category: t("articles.0.category"),
      title: t("articles.0.title"),
      excerpt: t("articles.0.excerpt"),
      content: t("articles.0.content"),
      readTime: t("articles.0.readTime"),
      author: t("articles.0.author"),
      date: t("articles.0.date"),
    },
    {
      category: t("articles.1.category"),
      title: t("articles.1.title"),
      excerpt: t("articles.1.excerpt"),
      content: t("articles.1.content"),
      readTime: t("articles.1.readTime"),
      author: t("articles.1.author"),
      date: t("articles.1.date"),
    },
    {
      category: t("articles.2.category"),
      title: t("articles.2.title"),
      excerpt: t("articles.2.excerpt"),
      content: t("articles.2.content"),
      readTime: t("articles.2.readTime"),
      author: t("articles.2.author"),
      date: t("articles.2.date"),
    },
  ];

  return (
    <>
      <section className="py-24 px-6 bg-warm-white">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-12 gap-4">
            <div>
              <SectionLabel>{t("label")}</SectionLabel>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-blue">{t("title")}</h2>
            </div>
            <Link href={`/${locale}/blog`}
              className="text-xs font-bold text-brand-blue flex items-center gap-2 hover:gap-3 transition-all uppercase tracking-widest">
              {t("viewAll")} <ArrowRight size={14} className="text-brand-cyan" />
            </Link>
          </div>

          {/* Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article, idx) => (
              <article
                key={idx}
                onClick={() => setSelected(article)}
                className="group bg-slate-50 p-7 rounded-[2rem] border border-slate-100 hover:bg-white hover:shadow-card-hover transition-all duration-500 flex flex-col h-full cursor-pointer"
              >
                <div className="flex items-center justify-between mb-6">
                  <span className="text-[10px] font-bold uppercase tracking-[0.15em] px-3 py-1 bg-white text-brand-blue rounded-lg border border-slate-100 group-hover:border-brand-cyan transition-colors">
                    {article.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                    <Clock size={12} /> {article.readTime}
                  </div>
                </div>

                <h3 className="text-lg font-heading font-bold text-brand-blue mb-4 leading-tight group-hover:text-brand-cyan transition-colors min-h-[48px]">
                  {article.title}
                </h3>

                <div className="pt-5 border-t border-slate-100 flex items-center justify-between mt-auto">
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-brand-blue">
                      <User size={14} />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{article.author}</span>
                  </div>
                  <ArrowRight size={14} className="text-brand-cyan" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Article Modal ─── */}
      {selected && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6"
          onClick={() => setSelected(null)}>
          <div className="absolute inset-0 bg-brand-blue/15 backdrop-blur-sm" />

          <div className="relative bg-white rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}>
            {/* Close */}
            <button onClick={() => setSelected(null)}
              className="absolute top-5 right-5 w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center hover:bg-slate-100 transition-colors z-10">
              <X size={20} className="text-slate-400" />
            </button>

            {/* Header */}
            <div className="p-8 md:p-10 pb-6 border-b border-slate-100">
              <div className="flex items-center gap-3 mb-5">
                <span className="bg-brand-blue text-white text-[10px] font-bold uppercase tracking-[0.15em] px-4 py-1.5 rounded-md">
                  {selected.category}
                </span>
                <span className="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                  <Clock size={12} /> {selected.readTime}
                </span>
              </div>

              <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-blue leading-tight mb-6">
                {selected.title}
              </h2>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-slate-100 flex items-center justify-center">
                    <User size={20} className="text-brand-blue" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-brand-blue">{selected.author}</p>
                    <p className="text-[10px] uppercase tracking-widest text-slate-400">{selected.date}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <div className="w-9 h-9 rounded-full bg-slate-50 flex items-center justify-center">
                    <Share2 size={14} className="text-slate-400" />
                  </div>
                </div>
              </div>
            </div>

            {/* Body */}
            <div className="p-8 md:p-10 bg-gradient-to-b from-warm-white to-white">
              {/* Excerpt as blockquote */}
              <div className="border-l-[3px] border-brand-gold pl-5 mb-7">
                <p className="text-base text-slate-500 italic leading-relaxed">{selected.excerpt}</p>
              </div>

              {/* Content paragraphs */}
              {selected.content.split("\n\n").map((para, i) => (
                <p key={i} className="text-sm text-slate-600 leading-[1.8] mb-5">{para}</p>
              ))}

              {/* Bottom CTA */}
              <div className="mt-8 p-6 bg-warm-white rounded-2xl text-center">
                <p className="text-sm font-semibold text-brand-blue mb-3">{t("articleCta")}</p>
                <a href={AI_URL} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-brand-gold hover:bg-brand-gold-hover text-brand-blue font-bold text-sm px-6 py-3 rounded-xl shadow-cta transition-all">
                  {t("articleCtaButton")}
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

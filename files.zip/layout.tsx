import type { ReactNode } from "react";
import type { Metadata } from "next";
import { NextIntlClientProvider, useMessages } from "next-intl";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { routing, type Locale } from "@/i18n/routing";

// ─── Constants ────────────────────────────────────────────────

const SITE_URL = "https://homepedia.com.au";
const GA_ID = process.env.NEXT_PUBLIC_GA_ID; // GA4 Property ID（P5.5 配置）

// ─── JSON-LD: AccountingService ──────────────────────────────

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "AccountingService",
  name: "Homepedia",
  description:
    "AI-powered tax preparation and accounting services for individuals and businesses in Australia",
  url: SITE_URL,
  email: "info@homepedia.com.au",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Sydney",
    addressRegion: "NSW",
    addressCountry: "AU",
  },
  areaServed: "AU",
  priceRange: "$$",
  knowsLanguage: ["en", "zh"],
};

// ─── Static params for SSG ───────────────────────────────────

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

// ─── Metadata ────────────────────────────────────────────────

type MetadataProps = {
  params: Promise<{ locale: Locale }>;
};

export async function generateMetadata({
  params,
}: MetadataProps): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "metadata" });

  // Build hreflang alternates: one entry per locale + x-default
  const languages: Record<string, string> = {};
  for (const loc of routing.locales) {
    languages[loc] = `${SITE_URL}/${loc}`;
  }
  languages["x-default"] = `${SITE_URL}/en`;

  return {
    title: {
      default: t("title.default"),
      template: t("title.template"),
    },
    description: t("description"),

    metadataBase: new URL(SITE_URL),

    alternates: {
      canonical: `${SITE_URL}/${locale}`,
      languages,
    },

    openGraph: {
      title: t("title.default"),
      description: t("description"),
      url: `${SITE_URL}/${locale}`,
      siteName: "Homepedia",
      locale: locale === "zh" ? "zh_CN" : "en_AU",
      type: "website",
      images: [
        {
          url: `${SITE_URL}/images/og-default.jpg`,
          width: 1200,
          height: 630,
          alt: "Homepedia — AI-Powered Tax & Accounting",
        },
      ],
    },

    twitter: {
      card: "summary_large_image",
      title: t("title.default"),
      description: t("description"),
      images: [`${SITE_URL}/images/og-default.jpg`],
    },

    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
  };
}

// ─── Layout Component ────────────────────────────────────────

type LayoutProps = {
  children: ReactNode;
  params: Promise<{ locale: Locale }>;
};

export default async function LocaleLayout({ children, params }: LayoutProps) {
  const { locale } = await params;

  // Enable static rendering for this locale
  setRequestLocale(locale);

  // Provide all messages to client components
  const messages = (await import(`@/messages/${locale}.json`)).default;

  return (
    <>
      {/* JSON-LD: AccountingService — 全站每页注入 */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* GA4 — 仅在有 Property ID 时注入（P5.5 配置环境变量后生效） */}
      {GA_ID && (
        <>
          <script
            async
            src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`}
          />
          <script
            dangerouslySetInnerHTML={{
              __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${GA_ID}');`,
            }}
          />
        </>
      )}

      <NextIntlClientProvider locale={locale} messages={messages}>
        {children}
      </NextIntlClientProvider>
    </>
  );
}

"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Sparkles } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";

const AI_URL = "https://app.homepedia.com.au";

export default function TaxEstimator() {
  const t = useTranslations("estimator");
  const [revenue, setRevenue] = useState(165000);
  const [deductions, setDeductions] = useState(12000);

  // Simplified progressive tax estimate (2024-25 rates)
  const taxableIncome = Math.max(0, revenue - deductions);
  const calculateTax = (income: number) => {
    if (income <= 18200) return 0;
    if (income <= 45000) return (income - 18200) * 0.19;
    if (income <= 120000) return 5092 + (income - 45000) * 0.325;
    if (income <= 180000) return 29467 + (income - 120000) * 0.37;
    return 51667 + (income - 180000) * 0.45;
  };
  const estimatedTax = Math.round(calculateTax(taxableIncome));

  return (
    <section className="py-24 px-6 bg-brand-blue relative overflow-hidden">
      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%">
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center relative z-10">
        {/* Left — label + result */}
        <div className="text-white">
          <SectionLabel>{t("label")}</SectionLabel>
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-8 leading-tight">{t("title")}</h2>
          <p className="text-blue-100/70 text-lg mb-12 leading-relaxed">{t("desc")}</p>

          <div className="p-8 bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20">
            <p className="text-xs font-bold uppercase tracking-widest mb-2 opacity-60">{t("resultLabel")}</p>
            <p className="text-5xl font-bold text-brand-gold mb-4 tabular-nums">
              ${estimatedTax.toLocaleString()}
            </p>
            <p className="text-sm opacity-80">{t("resultNote")}</p>
          </div>
        </div>

        {/* Right — sliders */}
        <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl">
          <div className="space-y-10">
            <div className="space-y-6">
              <div className="flex justify-between items-end">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t("revenueLabel")}</label>
                <span className="text-lg font-bold text-brand-blue">${revenue.toLocaleString()}</span>
              </div>
              <input
                type="range" min="0" max="500000" step="5000" value={revenue}
                onChange={(e) => setRevenue(Number(e.target.value))}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-brand-blue"
              />
            </div>

            <div className="space-y-6">
              <div className="flex justify-between items-end">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t("deductionsLabel")}</label>
                <span className="text-lg font-bold text-brand-blue">${deductions.toLocaleString()}</span>
              </div>
              <input
                type="range" min="0" max="80000" step="1000" value={deductions}
                onChange={(e) => setDeductions(Number(e.target.value))}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-brand-cyan"
              />
            </div>

            <a href={AI_URL} target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 bg-brand-gold hover:bg-brand-gold-hover text-brand-blue font-bold py-5 rounded-2xl transition-all shadow-cta">
              {t("cta")} <Sparkles size={20} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useTranslations } from "next-intl";
import { ShieldCheck, Anchor } from "lucide-react";
import CTAButton from "@/components/CTAButton";
import NetworkBackground from "./NetworkBackground";

const AI_URL = "https://app.homepedia.com.au";

export default function Hero() {
  const t = useTranslations("hero");

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden pt-20">
      <NetworkBackground />
      <div className="relative z-10 max-w-4xl text-center space-y-8">
        <div className="inline-block">
          <span className="bg-white/50 backdrop-blur-md px-4 py-1.5 rounded-full border border-slate-200 text-brand-blue text-[10px] font-bold uppercase tracking-[0.2em]">
            {t("badge")}
          </span>
        </div>

        <h1 className="text-5xl md:text-7xl font-heading font-bold leading-[1.08] tracking-tight text-brand-blue">
          {t("title")}
        </h1>

        <p className="text-xl md:text-2xl text-slate-500 max-w-2xl mx-auto font-light leading-relaxed">
          {t("subtitle")}
        </p>

        <div className="pt-4">
          <CTAButton href={AI_URL} external>{t("cta")}</CTAButton>
        </div>

        <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-4 sm:gap-0 pt-12 opacity-80">
          <div className="flex items-center gap-2 text-brand-blue font-semibold tracking-wide sm:border-r border-slate-200 sm:pr-8">
            <ShieldCheck size={20} className="text-brand-cyan" />
            <span className="text-[10px] uppercase tracking-widest">{t("trust1")}</span>
          </div>
          <div className="flex items-center gap-2 text-brand-blue font-semibold tracking-wide sm:pl-8">
            <Anchor size={20} className="text-brand-cyan" />
            <span className="text-[10px] uppercase tracking-widest">{t("trust2")}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

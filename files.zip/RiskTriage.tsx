"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { ChevronRight, AlertCircle } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";

const AI_URL = "https://app.homepedia.com.au";

export default function RiskTriage() {
  const t = useTranslations("triage");
  const [step, setStep] = useState(1);
  const [riskCount, setRiskCount] = useState(0);

  const totalQ = 3;
  const isResult = step > totalQ;

  const handleAnswer = (isYes: boolean) => {
    if (isYes) setRiskCount((c) => c + 1);
    setStep((s) => s + 1);
  };

  const reset = () => { setStep(1); setRiskCount(0); };

  return (
    <section className="py-24 px-6 bg-warm-white border-b border-slate-100">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-16">
          <SectionLabel>{t("label")}</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h2>
          <p className="text-slate-500">{t("subtitle")}</p>
        </div>

        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-elevated min-h-[400px] flex flex-col justify-center relative">
          {isResult ? (
            <div className="text-center animate-in fade-in">
              <div className="flex justify-center gap-3 mb-8">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className={`w-10 h-10 rounded-full flex items-center justify-center ${i < riskCount + 2 ? "bg-brand-gold" : "bg-slate-100"}`}>
                    {i < riskCount + 2 && <AlertCircle size={20} className="text-brand-blue" />}
                  </div>
                ))}
              </div>
              <h3 className="text-2xl font-heading font-bold text-brand-blue mb-4">{t("resultTitle")}</h3>
              <p className="text-slate-500 mb-8 max-w-md mx-auto">{t("resultDesc")}</p>
              <a href={AI_URL} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-brand-blue text-white font-bold px-8 py-4 rounded-xl hover:bg-brand-cyan transition-colors">
                {t("resultCta")}
              </a>
              <div className="mt-6">
                <button onClick={reset} className="text-xs font-bold text-slate-400 uppercase tracking-widest hover:text-brand-blue transition-colors">
                  {t("restart")}
                </button>
              </div>
            </div>
          ) : (
            <div key={step}>
              <p className="text-2xl md:text-3xl font-heading font-bold text-brand-blue mb-10 leading-tight">
                {t(`q${step}`)}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[true, false].map((isYes) => (
                  <button key={String(isYes)} onClick={() => handleAnswer(isYes)}
                    className="p-6 rounded-2xl border-2 border-slate-100 hover:border-brand-cyan hover:bg-slate-50 transition-all text-left group flex items-center justify-between">
                    <span className="text-lg font-bold text-slate-700 group-hover:text-brand-blue">
                      {isYes ? t("yes") : t("no")}
                    </span>
                    <ChevronRight size={20} className="text-slate-300 group-hover:text-brand-cyan group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
              <p className="text-center mt-6 text-xs text-slate-300">
                {t("progress", { current: step, total: totalQ })}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

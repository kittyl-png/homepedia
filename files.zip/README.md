# P0.4 — 根布局集成指南

## 产出文件

```
P0.4/
├── app/
│   ├── layout.tsx              ← 根布局（字体注入 + globals.css）
│   └── [locale]/
│       ├── layout.tsx          ← ★ 核心交付：locale 布局（metadata + JSON-LD + GA4 + NextIntlProvider）
│       └── page.tsx            ← 占位首页（验证用，P2 替换）
├── i18n/
│   ├── routing.ts              ← next-intl 路由定义（locales: en/zh）
│   └── request.ts              ← next-intl 请求配置（加载 messages JSON）
├── messages/
│   ├── en.json                 ← 英文翻译（nav/hero/footer/metadata/cta）
│   └── zh.json                 ← 中文翻译
├── middleware.ts               ← next-intl 中间件（语言检测 + 重定向）
└── next.config.ts              ← 更新：加入 next-intl 插件
```

## 安装依赖

```bash
npm install next-intl
```

## 放置规则

按目录结构直接放入项目根目录，覆盖已有文件：
- `app/layout.tsx` → 替换现有的 Geist 版本
- `next.config.ts` → 替换现有版本（新增 next-intl 插件）
- 其余文件为新增

## 依赖关系

| 依赖 | 来源 |
|------|------|
| `app/fonts.ts` | P0.3 产出 |
| `app/globals.css` | P0.3 产出 |

## layout.tsx 做了什么

### `app/layout.tsx`（根布局）
- 注入 `montserrat.variable` 和 `outfit.variable` CSS 变量到 `<html>`
- 加载 `globals.css`
- 不设 `<html lang>`（由 next-intl middleware 控制）
- 不设 metadata（由 locale layout 动态生成）

### `app/[locale]/layout.tsx`（★ P0.4 核心）

**Metadata（每个页面继承）：**
- `title.default` / `title.template` — 从 messages JSON 读取，支持中英文
- `description` — 从 messages JSON 读取
- `canonical` — `https://homepedia.com.au/{locale}`
- `hreflang` — `en`, `zh`, `x-default` 三个 alternate
- `openGraph` — title, description, image, locale (en_AU / zh_CN)
- `twitter` — summary_large_image
- `robots` — index, follow, googleBot 完整配置

**JSON-LD（AccountingService）：**
```json
{
  "@type": "AccountingService",
  "name": "Homepedia",
  "email": "info@homepedia.com.au",
  "address": { "addressLocality": "Sydney", "addressRegion": "NSW", "addressCountry": "AU" },
  "areaServed": "AU",
  "priceRange": "$$",
  "knowsLanguage": ["en", "zh"]
}
```

**GA4：**
- 通过 `NEXT_PUBLIC_GA_ID` 环境变量控制
- 未设置时不注入任何脚本（零影响）
- P5.5 配置环境变量后自动生效

**NextIntlClientProvider：**
- 包裹所有子页面
- 注入当前 locale 的 messages

## 子页面如何使用

```tsx
// 任何 app/[locale]/ 下的 page.tsx
import { useTranslations } from "next-intl";
import { setRequestLocale } from "next-intl/server";

export default async function SomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);

  return <div>...</div>;
}
```

子页面可通过 `generateMetadata` 覆盖 title/description：

```tsx
export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "metadata" });
  return {
    title: "About — Homepedia", // 会套用 template: "%s — Homepedia"
  };
}
```

## OG 图片占位

`/public/images/og-default.jpg` 需要在 P5.7 创建（1200×630px，品牌蓝 + Logo + tagline）。
在此之前 OG 图片链接存在但 404，不影响功能。

## 验证清单

- [ ] `npm run dev` 启动无报错
- [ ] 访问 `localhost:3000` → 自动重定向到 `/en`
- [ ] 访问 `/en` 和 `/zh` 都能看到占位首页
- [ ] 查看页面源码 → `<script type="application/ld+json">` 存在且正确
- [ ] 查看 `<head>` → hreflang、canonical、OG meta 都正确
- [ ] 占位首页标题用 Montserrat，正文用 Outfit
- [ ] 金色 CTA 按钮有品牌色阴影

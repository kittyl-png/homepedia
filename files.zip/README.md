# P2 — 首页集成指南

## 产出文件

```
P2/
├── components/home/
│   ├── NetworkBackground.tsx   ← 2.1 Canvas 粒子动画背景
│   ├── Hero.tsx                ← 2.1 首屏（徽章 + 标题 + CTA + 信任标记）
│   ├── RiskTriage.tsx          ← 2.2 互动诊断（3 题步进 + 结果）
│   ├── CoreServices.tsx        ← 2.3 三大服务卡片 + Outcome
│   ├── TaxEstimator.tsx        ← 2.4 税务估算器（双滑块 + 实时计算）
│   ├── Approach.tsx            ← 2.5 方法论（4 步流程）
│   ├── PricingPreview.tsx      ← 2.6 定价预览（模块化价目）
│   ├── BlogPreview.tsx         ← 2.7 博客预览（3 卡片 + 文章弹窗）
│   └── BottomCTA.tsx           ← 2.8 底部行动按钮
├── app/[locale]/page.tsx       ← 首页组装（导入所有 section）
└── messages/
    ├── en.json                 ← 替换 P0.4 版本（新增所有首页文案）
    └── zh.json                 ← 替换 P0.4 版本（新增所有首页中文文案）
```

## 放置规则

1. `components/home/*.tsx` → 放入项目 `components/home/` 目录
2. `app/[locale]/page.tsx` → 替换现有首页文件
3. `messages/en.json` / `zh.json` → **替换** P0.4 的版本（已包含 P0.4 原有内容 + P2 新增）

## 依赖

P1 已安装 `lucide-react`，无需新增依赖。

## 各 Section 说明

### 2.1 Hero (`Hero.tsx` + `NetworkBackground.tsx`)

- 全屏高度，暖白背景 + Canvas 粒子动画叠加
- 磨砂玻璃徽章（TPB 执照号）
- Montserrat 大标题 + Outfit 副标题
- 金色主 CTA → `app.homepedia.com.au`
- 信任标记：ShieldCheck + Anchor 图标（Lucide），竖线分隔
- **移动端**：粒子降至 20 个，DPR 限制 1，信任标记纵向堆叠

### 2.2 RiskTriage (`RiskTriage.tsx`)

- 白色大圆角卡片（`rounded-3xl shadow-elevated`）
- 3 个问题逐一展示，点击 Yes/No 推进
- 结果页显示风险指示灯（金色圆点）+ CTA 跳 AI 助手
- "重新开始" 按钮重置
- **翻译 key**: `triage.q1` / `triage.q2` / `triage.q3`

### 2.3 CoreServices (`CoreServices.tsx`)

- 3 列 grid（移动端单列）
- 每张卡片：Lucide 图标 + 标题 + 描述 + "Outcome:" 金色圆点
- hover 阴影提升

### 2.4 TaxEstimator (`TaxEstimator.tsx`)

- 深蓝背景 + 网格图案叠加
- 左侧：标签 + 标题 + 玻璃态结果卡（金色大数字）
- 右侧：白色圆角卡 + 双滑块（收入 0-500k / 扣除 0-80k）
- **税率计算**：使用 2024-25 累进税率（18200 免税 → 19% → 32.5% → 37% → 45%）
- 全宽金色 CTA → AI 助手

### 2.5 Approach (`Approach.tsx`)

- 4 列 grid，中线装饰
- 每张卡片有半透明大号序号（01-04）
- hover 时边框变青色

### 2.6 PricingPreview (`PricingPreview.tsx`)

- 列表式价目（5 项），基础项用青色圆点标记
- 双 CTA：金色"获取报价" + 描边"查看完整价格"
- **数据来源**：暂从翻译文件读取，P3.2 完成后可改为读 `pricing.json`

### 2.7 BlogPreview (`BlogPreview.tsx`)

- 3 列卡片 grid，hover 阴影 + 背景色变化
- **点击卡片弹出文章弹窗**：
  - 分类标签（深蓝底白字）+ 阅读时间
  - 大标题（Montserrat）
  - 作者头像 + 日期 + 分享图标
  - 金色左边线引用（excerpt）
  - 正文段落
  - 底部 CTA 卡片 → AI 助手
- 点击背景或 ✕ 关闭
- **P4 完成后**：hardcoded 文章改为动态读取最新 3 篇 Markdown

### 2.8 BottomCTA (`BottomCTA.tsx`)

- 居中标题 + 双按钮（金色主 CTA + 深蓝次 CTA）
- 复用 `CTAButton` 共享组件

## 翻译结构变更

相比 P0.4 的 `en.json` / `zh.json`，新增以下 namespace：

| Namespace | Section |
|-----------|---------|
| `triage` | 2.2 互动诊断 |
| `services` | 2.3 服务卡片 |
| `estimator` | 2.4 税务估算 |
| `approach` | 2.5 方法论 |
| `pricingPreview` | 2.6 定价预览 |
| `blogPreview` | 2.7 博客预览 |
| `bottomCta` | 2.8 底部 CTA |

`hero` namespace 中 `trustAgent`/`trustABN` 改为 `trust1`/`trust2`。

## 验证清单

- [ ] `npm run dev` 无报错
- [ ] 访问 `/en` — 看到完整 8 section 首页
- [ ] Hero 粒子动画运行流畅
- [ ] 互动诊断可点击答题，3 题后显示结果
- [ ] 税务估算器滑块可拖动，数字实时更新
- [ ] 博客卡片点击弹出文章弹窗，有分类/作者/日期/正文
- [ ] 弹窗底部 CTA "Talk to our AI Assistant" 链接正确
- [ ] 语言切换后所有文案变为中文
- [ ] 缩小到移动端 — 卡片单列，粒子减少，CTA 按钮正常
- [ ] 底部 CTA 两个按钮链接正确（AI 助手 + Contact）

import type { ReactNode } from "react";
import { montserrat, outfit } from "./fonts";
import "./globals.css";

/**
 * Root layout — 最外层壳。
 * 职责：注入字体 CSS 变量 + 加载全局样式。
 * 不设 metadata（由 [locale]/layout.tsx 根据语言动态生成）。
 * 不设 lang 属性（由 [locale]/layout.tsx 根据 locale 设置）。
 */
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html className={`${montserrat.variable} ${outfit.variable}`} suppressHydrationWarning>
      <body className="antialiased">{children}</body>
    </html>
  );
}

import { useTranslations } from "next-intl";
import { Shield, BarChart3, Globe } from "lucide-react";
import SectionLabel from "@/components/SectionLabel";

const icons = [
  <Shield key="s" size={32} className="text-brand-blue" />,
  <BarChart3 key="b" size={32} className="text-brand-blue" />,
  <Globe key="g" size={32} className="text-brand-blue" />,
];

export default function CoreServices() {
  const t = useTranslations("services");
  const keys = ["compliance", "cfo", "structure"] as const;

  return (
    <section className="py-24 px-6 bg-warm-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <SectionLabel>{t("label")}</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-blue">{t("title")}</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {keys.map((key, idx) => (
            <div key={key} className="bg-white p-8 rounded-2xl shadow-card hover:shadow-card-hover transition-shadow duration-300 border border-slate-100 flex flex-col h-full">
              <div className="mb-6 p-4 rounded-xl bg-slate-50 inline-block w-fit">
                {icons[idx]}
              </div>
              <h3 className="text-xl font-heading font-bold mb-4 text-brand-blue">{t(`${key}.title`)}</h3>
              <p className="text-slate-600 mb-8 leading-relaxed flex-grow text-sm">{t(`${key}.desc`)}</p>
              <div className="mt-auto pt-6 border-t border-slate-50">
                <div className="flex items-start gap-3">
                  <span className="w-1.5 h-1.5 mt-1.5 rounded-full bg-brand-gold shrink-0" />
                  <p className="text-xs font-semibold text-brand-blue leading-snug">
                    <span className="text-slate-400 font-normal italic mr-1">Outcome:</span>
                    {t(`${key}.outcome`)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

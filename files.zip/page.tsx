import { setRequestLocale } from "next-intl/server";
import Hero from "@/components/home/Hero";
import RiskTriage from "@/components/home/RiskTriage";
import CoreServices from "@/components/home/CoreServices";
import TaxEstimator from "@/components/home/TaxEstimator";
import Approach from "@/components/home/Approach";
import PricingPreview from "@/components/home/PricingPreview";
import BlogPreview from "@/components/home/BlogPreview";
import BottomCTA from "@/components/home/BottomCTA";

type Props = {
  params: Promise<{ locale: string }>;
};

export default async function HomePage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return (
    <div className="animate-in fade-in duration-500">
      <Hero />
      <RiskTriage />
      <CoreServices />
      <TaxEstimator />
      <Approach />
      <PricingPreview />
      <BlogPreview />
      <BottomCTA />
    </div>
  );
}

import { useTranslations } from "next-intl";
import { setRequestLocale } from "next-intl/server";

type Props = {
  params: Promise<{ locale: string }>;
};

export default async function HomePage({ params }: Props) {
  const { locale } = await params;
  setRequestLocale(locale);

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="text-center max-w-2xl">
        {/* Section label */}
        <span className="text-xs font-bold text-brand-cyan uppercase tracking-[0.3em] mb-4 block">
          {locale === "zh" ? "开发中" : "Under Construction"}
        </span>

        {/* Heading — uses Montserrat via font-heading */}
        <h1 className="font-heading font-bold text-5xl md:text-7xl text-brand-blue mb-6">
          Homepedia
        </h1>

        {/* Subtitle — uses Outfit (default sans) */}
        <p className="text-lg md:text-xl text-slate-500 font-light leading-relaxed mb-10">
          {locale === "zh"
            ? "AI 驱动的智能报税服务，由专业会计师全程把关"
            : "AI-powered tax preparation backed by human expertise"}
        </p>

        {/* CTA button — gold primary style from design system */}
        <a
          href="https://app.homepedia.com.au"
          className="inline-block bg-brand-gold hover:bg-brand-gold-hover text-brand-blue font-bold py-4 px-10 rounded-xl shadow-cta active:scale-95 transition-all"
        >
          {locale === "zh" ? "开始使用 AI 助手" : "Start with AI Assistant"}
        </a>

        {/* Trust marks */}
        <div className="mt-8 flex flex-col md:flex-row items-center justify-center gap-4 text-[10px] uppercase tracking-widest text-slate-400">
          <span>🛡 Registered Tax Agent</span>
          <span>⚓ ABN 44 643 057 354</span>
        </div>
      </div>
    </main>
  );
}

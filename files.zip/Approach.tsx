import { useTranslations } from "next-intl";
import SectionLabel from "@/components/SectionLabel";

export default function Approach() {
  const t = useTranslations("approach");
  const steps = [0, 1, 2, 3] as const;

  return (
    <section className="py-24 px-6 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-1/2 w-px h-full bg-slate-100 -translate-x-1/2" />

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-20">
          <SectionLabel>{t("label")}</SectionLabel>
          <h2 className="text-3xl md:text-5xl font-heading font-bold text-brand-blue mb-6">{t("title")}</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">{t("subtitle")}</p>
        </div>

        <div className="grid md:grid-cols-4 gap-4">
          {steps.map((idx) => (
            <div key={idx} className="bg-warm-white p-8 rounded-2xl border border-slate-100 hover:border-brand-cyan transition-all group">
              <div className="text-4xl font-bold text-slate-200 mb-6 group-hover:text-brand-cyan/20 transition-colors">
                {String(idx + 1).padStart(2, "0")}
              </div>
              <h3 className="text-lg font-heading font-bold text-brand-blue mb-4">{t(`steps.${idx}.title`)}</h3>
              <p className="text-sm text-slate-500 leading-relaxed">{t(`steps.${idx}.desc`)}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

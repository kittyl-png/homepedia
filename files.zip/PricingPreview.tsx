import { useTranslations } from "next-intl";
import { useLocale } from "next-intl";
import Link from "next/link";
import SectionLabel from "@/components/SectionLabel";

const AI_URL = "https://app.homepedia.com.au";

export default function PricingPreview() {
  const t = useTranslations("pricingPreview");
  const locale = useLocale();

  const items = [0, 1, 2, 3, 4] as const;

  return (
    <section className="py-24 px-6 bg-warm-white">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <SectionLabel>{t("label")}</SectionLabel>
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-blue mb-4">{t("title")}</h2>
          <p className="text-slate-500">{t("subtitle")}</p>
        </div>

        <div className="bg-white rounded-2xl p-8 md:p-10 shadow-card border border-slate-100">
          {items.map((idx) => (
            <div key={idx} className={`flex justify-between items-center py-5 ${idx < items.length - 1 ? "border-b border-slate-50" : ""}`}>
              <div className="flex items-center gap-3">
                <span className={`w-2 h-2 rounded-full ${idx === 0 ? "bg-brand-cyan" : "bg-slate-200"}`} />
                <span className={`text-sm ${idx === 0 ? "font-bold text-brand-blue" : "font-medium text-brand-blue"}`}>
                  {t(`items.${idx}.label`)}
                </span>
              </div>
              <span className={`text-sm font-bold ${idx === 0 ? "text-brand-blue" : "text-slate-500"}`}>
                {t(`items.${idx}.price`)}
              </span>
            </div>
          ))}

          <div className="flex flex-col sm:flex-row gap-3 mt-8">
            <a href={AI_URL} target="_blank" rel="noopener noreferrer"
              className="flex-1 text-center bg-brand-gold hover:bg-brand-gold-hover text-brand-blue font-bold py-4 rounded-xl shadow-cta transition-all text-sm">
              {t("ctaPrimary")}
            </a>
            <Link href={`/${locale}/pricing`}
              className="flex-1 text-center border-2 border-slate-200 text-brand-blue font-bold py-4 rounded-xl hover:bg-slate-50 transition-all text-sm">
              {t("ctaSecondary")}
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

# Homepedia Website

Company website for Homepedia Pty Ltd — AI-powered tax preparation and accounting services.

## Tech Stack

- **Next.js 16** (App Router)
- **React 19**
- **Tailwind CSS 4**
- **TypeScript**
- **next-intl** (i18n — English + Chinese)

## Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Related

- **AI Tax Assistant:** [app.homepedia.com.au](https://app.homepedia.com.au) (separate repo: `homepedia-assistant`)

## Architecture Docs

See Project Knowledge in Claude:
- `homepedia-website-architecture-v2.md`
- `homepedia-design-system.md`
- `homepedia-mobile-seo.md`
- `homepedia-website-build-tasks.md`

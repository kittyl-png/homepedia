import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // next-intl plugin will be added in P0.2
};

export default nextConfig;

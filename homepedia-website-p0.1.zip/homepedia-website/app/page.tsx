export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen px-6">
      {/* Logo */}
      <div className="w-12 h-12 rounded-xl gradient-blue flex items-center justify-center text-white font-bold text-2xl shadow-lg shadow-blue-500/20 mb-6">
        H
      </div>

      {/* Title */}
      <h1 className="text-5xl font-bold tracking-tight text-brand-deep-blue mb-4">
        Homepedia
      </h1>

      {/* Subtitle */}
      <p className="text-lg text-body max-w-md text-center mb-8">
        AI-powered tax preparation backed by registered tax agents.
      </p>

      {/* CTA */}
      <a
        href="https://app.homepedia.com.au"
        className="bg-brand-gold hover:bg-brand-gold-hover text-brand-deep-blue font-bold py-4 px-10 rounded-xl shadow-2xl shadow-brand-gold/30 active:scale-95 transition-all"
      >
        Try AI Assistant →
      </a>

      {/* Trust badges */}
      <div className="flex items-center gap-6 mt-12 text-[10px] font-bold uppercase tracking-widest text-brand-deep-blue/60">
        <span>Registered Tax Agent · TPB #26336583</span>
        <span>ABN 44 643 057 354</span>
      </div>

      {/* Stack verification */}
      <p className="mt-16 text-xs text-slate-300">
        Next.js 16 · Tailwind 4 · TypeScript ✓
      </p>
    </main>
  );
}

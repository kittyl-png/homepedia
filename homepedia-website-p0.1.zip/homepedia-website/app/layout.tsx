import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Homepedia — AI-Powered Tax & Accounting in Australia",
  description:
    "Smart tax preparation backed by registered tax agents. Individual tax returns, business tax, bookkeeping & CFO advisory.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-brand-warm-white text-heading antialiased">
        {children}
      </body>
    </html>
  );
}

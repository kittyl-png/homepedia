import { NextRequest, NextResponse } from "next/server";
import { appendEnquiry } from "@/lib/sheets";

// ---------------------------------------------------------------------------
//  POST /api/enquiry
//  Body: { name, email, phone?, service, message }
//  Writes a timestamped row to Google Sheets.
// ---------------------------------------------------------------------------

interface EnquiryBody {
  name: string;
  email: string;
  phone?: string;
  service: string;
  message: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: EnquiryBody = await request.json();

    // --- basic validation ---------------------------------------------------
    if (!body.name?.trim() || !body.email?.trim() || !body.service?.trim()) {
      return NextResponse.json(
        { error: "Name, email and service are required." },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(body.email)) {
      return NextResponse.json(
        { error: "Invalid email address." },
        { status: 400 }
      );
    }

    // --- write to Google Sheets ---------------------------------------------
    const timestamp = new Date().toISOString();

    await appendEnquiry({
      timestamp,
      name: body.name.trim(),
      email: body.email.trim(),
      phone: (body.phone ?? "").trim(),
      service: body.service.trim(),
      message: (body.message ?? "").trim(),
    });

    return NextResponse.json({ success: true, timestamp });
  } catch (err: unknown) {
    console.error("[/api/enquiry] Error:", err);
    return NextResponse.json(
      { error: "Internal server error. Please try again later." },
      { status: 500 }
    );
  }
}

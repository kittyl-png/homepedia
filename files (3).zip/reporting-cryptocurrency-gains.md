---
title: "How to Report Cryptocurrency Gains on Your Australian Tax Return"
date: "2026-01-28"
excerpt: "Crypto is not tax-free in Australia. Learn how the ATO treats digital assets and what records you need to keep."
cover: "/images/blog/crypto-tax.jpg"
category: "crypto"
author: "Homepedia"
readTime: "7 min"
---

If you've bought, sold, swapped, or earned cryptocurrency during the financial year, you likely have a tax obligation. The ATO treats most digital assets as property for capital gains tax (CGT) purposes, which means disposals can trigger a taxable event.

## What Counts as a CGT Event?

In Australia, the following actions are considered disposals for CGT purposes:

- Selling cryptocurrency for Australian dollars or another fiat currency
- Trading one cryptocurrency for another (e.g. swapping ETH for BTC)
- Using cryptocurrency to pay for goods or services
- Gifting cryptocurrency to another person
- Converting crypto to a stablecoin

Each of these triggers a capital gain or capital loss, calculated as the difference between what you received and your cost base.

## The 12-Month CGT Discount

If you hold a crypto asset for more than 12 months before disposing of it, you may be entitled to a 50% CGT discount as an individual taxpayer. This can significantly reduce the tax payable on long-term holdings.

**Example:** You bought 1 ETH for $2,000 and sold it 18 months later for $5,000. Your capital gain is $3,000, but after the 50% discount, only $1,500 is added to your assessable income.

## Staking, Airdrops, and DeFi

The tax treatment of staking rewards, airdrops, and DeFi earnings can be complex:

- **Staking rewards** are generally treated as ordinary income at the time you receive them, valued at the market price on that date.
- **Airdrops** may be treated as ordinary income if received in relation to an existing holding or service, or as a CGT asset with a zero cost base if unsolicited.
- **DeFi lending and liquidity pools** — each transaction in and out of a pool may be a separate CGT event.

## Record-Keeping Requirements

The ATO requires you to keep records of every crypto transaction for at least five years. This includes:

- The date of each transaction
- The amount in Australian dollars at the time
- What the transaction was for
- The other party (exchange or wallet address)
- Receipts or exchange records

## Common Mistakes

- **Not reporting crypto-to-crypto trades.** Swapping one token for another is a disposal, even if you never converted to AUD.
- **Using the wrong cost base.** If you bought the same asset at different times, you need to track each parcel separately (or use a consistent method like FIFO).
- **Forgetting DeFi transactions.** Liquidity pool entries, yield farming, and bridge transactions can all be CGT events.

---

## Need Help With Crypto Tax?

Cryptocurrency tax can be complex, especially if you've used multiple exchanges or participated in DeFi. Our AI Tax Assistant can help you understand what needs to be reported, and our registered tax agents will review the final return to make sure everything is compliant.

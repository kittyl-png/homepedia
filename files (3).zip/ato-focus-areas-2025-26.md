---
title: "ATO Focus Areas for 2025–26: What to Watch Out For"
date: "2026-02-10"
excerpt: "The ATO has flagged several priority areas this financial year. Here's what they're looking at and how to make sure your return is compliant."
cover: "/images/blog/ato-focus-areas.jpg"
category: "compliance"
author: "Homepedia"
readTime: "6 min"
---

Each year the Australian Taxation Office publishes its compliance priorities — the areas where it will direct its data matching, audits, and reviews. For the 2025–26 financial year, several themes stand out that every taxpayer should be aware of.

## Rental Property Deductions

Investment property remains one of the ATO's top focus areas. Common errors include claiming private expenses against rental income, incorrectly apportioning costs for holiday homes that are also rented out, and overclaiming on renovation costs that should be capitalised rather than immediately deducted.

**What to do:** Ensure you have a clear distinction between repairs (deductible) and improvements (depreciable). If your property was vacant for part of the year, only claim expenses for the period it was genuinely available for rent.

## Work-Related Expenses Without Records

The ATO has consistently flagged that many taxpayers are claiming work-related deductions without adequate records. The days of "standard deductions" are over — every claim needs to be substantiated with receipts, invoices, or diary entries.

**What to do:** Digitise your receipts throughout the year. The myDeductions tool in the ATO app is one option; any systematic record-keeping method works.

## Cryptocurrency and Digital Assets

Crypto disposals — including trading one token for another, using crypto to pay for goods and services, and converting to fiat — are all CGT events. The ATO has data-sharing agreements with Australian exchanges and is actively matching transactions to individual taxpayers.

**What to do:** Export your full transaction history from every exchange you've used. Tools like Koinly or CryptoTaxCalculator can help generate a capital gains summary. Don't forget DeFi transactions, airdrops, and staking rewards.

## Side Hustles and the Gig Economy

If you earn income from rideshare driving, freelancing, selling goods online, or other gig work, the ATO expects you to declare it. This includes income paid in cash or through overseas platforms.

**What to do:** Report all income, even if no PAYG summary is issued. You may be able to offset business expenses against this income if you maintain proper records.

## Overclaiming Deductions for Genuine Work Expenses

Even where a deduction is legitimate, the ATO is scrutinising the *amount* claimed. For example, claiming 100% of a phone bill when only 60% of usage is work-related, or claiming an entire uniform when only specific items qualify.

**What to do:** Apply a reasonable apportionment. Document how you arrived at the percentage — the ATO may ask for your methodology during a review.

---

## Stay Compliant With Confidence

Our team of registered tax agents reviews every return prepared through our platform. If you're unsure about any of these areas, our AI Tax Assistant can help you assess your situation before lodgement.

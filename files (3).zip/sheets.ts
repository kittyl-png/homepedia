import { google } from "googleapis";

// ---------------------------------------------------------------------------
//  Google Sheets helper – append a row to the Enquiry sheet
//  Requires env vars:
//    GOOGLE_SERVICE_ACCOUNT_EMAIL
//    GOOGLE_PRIVATE_KEY          (PEM, with literal \n replaced at runtime)
//    GOOGLE_SHEET_ID             (the long ID in the Sheet URL)
// ---------------------------------------------------------------------------

const SCOPES = ["https://www.googleapis.com/auth/spreadsheets"];

function getAuth() {
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n");

  if (!email || !key) {
    throw new Error(
      "Missing GOOGLE_SERVICE_ACCOUNT_EMAIL or GOOGLE_PRIVATE_KEY env vars"
    );
  }

  return new google.auth.JWT({
    email,
    key,
    scopes: SCOPES,
  });
}

export interface EnquiryRow {
  timestamp: string;
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}

/**
 * Append one enquiry row to the first sheet.
 * Columns: Timestamp | Name | Email | Phone | Service | Message
 */
export async function appendEnquiry(data: EnquiryRow): Promise<void> {
  const sheetId = process.env.GOOGLE_SHEET_ID;
  if (!sheetId) throw new Error("Missing GOOGLE_SHEET_ID env var");

  const auth = getAuth();
  const sheets = google.sheets({ version: "v4", auth });

  await sheets.spreadsheets.values.append({
    spreadsheetId: sheetId,
    range: "Sheet1!A:F",
    valueInputOption: "USER_ENTERED",
    requestBody: {
      values: [
        [
          data.timestamp,
          data.name,
          data.email,
          data.phone,
          data.service,
          data.message,
        ],
      ],
    },
  });
}

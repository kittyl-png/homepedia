import type { MetadataRoute } from "next";
import { getAllSlugs } from "@/lib/blog";

// ---------------------------------------------------------------------------
//  app/sitemap.ts — Dynamic sitemap with hreflang alternates
// ---------------------------------------------------------------------------

const BASE = "https://homepedia.com.au";
const LOCALES = ["en", "zh"] as const;

// Static pages (path without locale prefix)
const STATIC_PAGES = [
  { path: "", changeFrequency: "weekly" as const, priority: 1.0 },
  { path: "/about", changeFrequency: "monthly" as const, priority: 0.8 },
  { path: "/services", changeFrequency: "monthly" as const, priority: 0.9 },
  { path: "/pricing", changeFrequency: "monthly" as const, priority: 0.9 },
  { path: "/blog", changeFrequency: "weekly" as const, priority: 0.8 },
  { path: "/contact", changeFrequency: "monthly" as const, priority: 0.7 },
  { path: "/faq", changeFrequency: "monthly" as const, priority: 0.7 },
  { path: "/privacy", changeFrequency: "yearly" as const, priority: 0.3 },
  { path: "/terms", changeFrequency: "yearly" as const, priority: 0.3 },
];

function buildAlternates(pagePath: string) {
  const languages: Record<string, string> = {};
  for (const locale of LOCALES) {
    languages[locale] = `${BASE}/${locale}${pagePath}`;
  }
  // x-default falls back to English
  languages["x-default"] = `${BASE}/en${pagePath}`;
  return { languages };
}

export default function sitemap(): MetadataRoute.Sitemap {
  const entries: MetadataRoute.Sitemap = [];

  // ── Static pages (one entry per locale) ──
  for (const page of STATIC_PAGES) {
    for (const locale of LOCALES) {
      entries.push({
        url: `${BASE}/${locale}${page.path}`,
        changeFrequency: page.changeFrequency,
        priority: page.priority,
        alternates: buildAlternates(page.path),
      });
    }
  }

  // ── Blog posts ──
  const slugs = getAllSlugs();
  // Deduplicate slugs (same slug may appear for both locales)
  const uniqueSlugs = [...new Set(slugs.map((s) => s.slug))];

  for (const slug of uniqueSlugs) {
    const blogPath = `/blog/${slug}`;
    for (const locale of LOCALES) {
      entries.push({
        url: `${BASE}/${locale}${blogPath}`,
        changeFrequency: "monthly",
        priority: 0.7,
        alternates: buildAlternates(blogPath),
      });
    }
  }

  return entries;
}

import type { Metadata } from "next";

// ---------------------------------------------------------------------------
//  lib/metadata.ts — Shared metadata builder
//  Usage: return buildPageMetadata({ locale, page: "about" })
// ---------------------------------------------------------------------------

const BASE = "https://homepedia.com.au";
const SITE_NAME = "Homepedia";
const DEFAULT_OG_IMAGE = `${BASE}/images/og-default.jpg`;

// ── Per-page SEO config ──

interface PageSeo {
  titleEn: string;
  titleZh: string;
  descriptionEn: string;
  descriptionZh: string;
}

const PAGE_SEO: Record<string, PageSeo> = {
  home: {
    titleEn: "Homepedia — AI-Powered Tax & Accounting in Australia",
    titleZh: "Homepedia — 澳洲智能报税与会计服务",
    descriptionEn:
      "AI-powered tax preparation backed by registered tax agents. Individual tax, business tax, and bookkeeping services for Australians.",
    descriptionZh:
      "由注册税务代理支持的 AI 智能报税服务。为澳洲个人和企业提供报税、记账和财务咨询。",
  },
  about: {
    titleEn: "About Homepedia — Registered Tax Agent Sydney",
    titleZh: "关于 Homepedia — 悉尼注册税务代理",
    descriptionEn:
      "Meet the team behind Homepedia. Registered tax agents combining AI technology with human expertise to deliver accurate, affordable tax services.",
    descriptionZh:
      "认识 Homepedia 团队。注册税务代理将 AI 技术与专业人员相结合，提供准确、实惠的税务服务。",
  },
  services: {
    titleEn: "Tax Return & Accounting Services — Homepedia",
    titleZh: "报税与会计服务 — Homepedia",
    descriptionEn:
      "Individual tax returns, business tax, bookkeeping and CFO advisory. AI-assisted preparation reviewed by registered tax agents.",
    descriptionZh:
      "个人报税、公司报税、记账和 CFO 咨询服务。AI 辅助准备，注册税务代理审核。",
  },
  pricing: {
    titleEn: "Tax Return Pricing from $220 — Homepedia",
    titleZh: "报税费用 $220 起 — Homepedia",
    descriptionEn:
      "Transparent pricing for individual and business tax returns. No hidden fees. Get a personalised quote with our AI assistant.",
    descriptionZh:
      "个人和企业报税透明定价，无隐藏费用。通过 AI 助手获取个性化报价。",
  },
  blog: {
    titleEn: "Tax Tips & Insights — Homepedia Blog",
    titleZh: "税务知识与资讯 — Homepedia 博客",
    descriptionEn:
      "Tax tips, ATO updates, and financial insights for Australian individuals and businesses. Stay informed with Homepedia.",
    descriptionZh:
      "面向澳洲个人和企业的税务技巧、ATO 动态和财务资讯。Homepedia 助您掌握最新信息。",
  },
  contact: {
    titleEn: "Contact Homepedia — Book a Consultation",
    titleZh: "联系我们 — Homepedia",
    descriptionEn:
      "Get in touch with Homepedia. Book a consultation or send us an enquiry about our tax and accounting services.",
    descriptionZh:
      "联系 Homepedia。预约咨询或发送关于税务和会计服务的询问。",
  },
  faq: {
    titleEn: "Frequently Asked Questions — Homepedia",
    titleZh: "常见问题 — Homepedia",
    descriptionEn:
      "Answers to common questions about tax returns, pricing, our AI assistant, and how Homepedia works.",
    descriptionZh:
      "关于报税、定价、AI 助手以及 Homepedia 运作方式的常见问题解答。",
  },
  privacy: {
    titleEn: "Privacy Policy — Homepedia",
    titleZh: "隐私政策 — Homepedia",
    descriptionEn:
      "How Homepedia collects, uses, and protects your personal information in accordance with the Australian Privacy Act 1988.",
    descriptionZh:
      "Homepedia 如何根据澳洲《隐私法 1988》收集、使用和保护您的个人信息。",
  },
  terms: {
    titleEn: "Terms of Service — Homepedia",
    titleZh: "服务条款 — Homepedia",
    descriptionEn:
      "Terms and conditions governing the use of Homepedia's website and AI Tax Assistant services.",
    descriptionZh:
      "使用 Homepedia 网站和 AI 税务助手服务的条款与条件。",
  },
};

// ── Builder ──

interface BuildOptions {
  locale: string;
  page: string;
  /** Override the path segment (defaults to page key, e.g. "about" → /about) */
  path?: string;
  /** Override OG image URL */
  ogImage?: string;
}

export function buildPageMetadata({
  locale,
  page,
  path,
  ogImage,
}: BuildOptions): Metadata {
  const seo = PAGE_SEO[page] ?? PAGE_SEO.home;
  const isZh = locale === "zh";
  const altLocale = isZh ? "en" : "zh";

  const pagePath = path ?? (page === "home" ? "" : `/${page}`);
  const canonicalUrl = `${BASE}/${locale}${pagePath}`;
  const alternateUrl = `${BASE}/${altLocale}${pagePath}`;

  const title = isZh ? seo.titleZh : seo.titleEn;
  const description = isZh ? seo.descriptionZh : seo.descriptionEn;
  const image = ogImage ?? DEFAULT_OG_IMAGE;

  return {
    title,
    description,
    alternates: {
      canonical: canonicalUrl,
      languages: {
        [locale]: canonicalUrl,
        [altLocale]: alternateUrl,
        "x-default": `${BASE}/en${pagePath}`,
      },
    },
    openGraph: {
      title,
      description,
      url: canonicalUrl,
      siteName: SITE_NAME,
      type: "website",
      locale: isZh ? "zh_CN" : "en_AU",
      images: [{ url: image, width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [image],
    },
  };
}

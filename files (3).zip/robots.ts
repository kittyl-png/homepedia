import type { MetadataRoute } from "next";

// ---------------------------------------------------------------------------
//  app/robots.ts — robots.txt
// ---------------------------------------------------------------------------

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
      },
    ],
    sitemap: "https://homepedia.com.au/sitemap.xml",
  };
}

import fs from "fs";
import path from "path";
import matter from "gray-matter";

// ---------------------------------------------------------------------------
//  Blog data layer
//  Reads content/blog/{locale}/*.md with gray-matter.
// ---------------------------------------------------------------------------

const BLOG_DIR = path.join(process.cwd(), "content", "blog");

export interface PostFrontmatter {
  title: string;
  date: string;
  excerpt: string;
  cover: string;
  category: string;
  author: string;
  readTime: string;
}

export interface PostMeta extends PostFrontmatter {
  slug: string;
  locale: string;
}

export interface Post extends PostMeta {
  content: string; // raw markdown body
}

// ── helpers ----------------------------------------------------------------

function localeDir(locale: string) {
  return path.join(BLOG_DIR, locale);
}

function readPost(locale: string, filename: string): Post {
  const filePath = path.join(localeDir(locale), filename);
  const raw = fs.readFileSync(filePath, "utf-8");
  const { data, content } = matter(raw);
  const slug = filename.replace(/\.md$/, "");

  return {
    slug,
    locale,
    content,
    title: data.title ?? slug,
    date: data.date ?? "",
    excerpt: data.excerpt ?? "",
    cover: data.cover ?? "",
    category: data.category ?? "general",
    author: data.author ?? "Homepedia",
    readTime: data.readTime ?? "5 min",
  };
}

// ── public API -------------------------------------------------------------

/** All posts for a locale, sorted newest-first. */
export function getAllPosts(locale: string): PostMeta[] {
  const dir = localeDir(locale);
  if (!fs.existsSync(dir)) return [];

  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".md"))
    .map((f) => {
      const { content: _content, ...meta } = readPost(locale, f);
      return meta;
    })
    .sort((a, b) => (a.date > b.date ? -1 : 1));
}

/** Single post by slug (includes body markdown). */
export function getPostBySlug(locale: string, slug: string): Post | null {
  const filename = `${slug}.md`;
  const filePath = path.join(localeDir(locale), filename);
  if (!fs.existsSync(filePath)) return null;
  return readPost(locale, filename);
}

/** All slugs across all locales (for sitemap / static params). */
export function getAllSlugs(): { locale: string; slug: string }[] {
  const locales = fs.existsSync(BLOG_DIR)
    ? fs.readdirSync(BLOG_DIR).filter((d) => {
        return fs.statSync(path.join(BLOG_DIR, d)).isDirectory();
      })
    : [];

  const results: { locale: string; slug: string }[] = [];

  for (const locale of locales) {
    const dir = localeDir(locale);
    for (const file of fs.readdirSync(dir).filter((f) => f.endsWith(".md"))) {
      results.push({ locale, slug: file.replace(/\.md$/, "") });
    }
  }

  return results;
}

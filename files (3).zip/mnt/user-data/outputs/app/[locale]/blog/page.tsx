import { useTranslations, useLocale } from "next-intl";
import { getTranslations } from "next-intl/server";
import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { Calendar, Clock, ArrowRight, BookOpen } from "lucide-react";
import { getAllPosts, type PostMeta } from "@/lib/blog";
import { buildPageMetadata } from "@/lib/metadata";

// ---------------------------------------------------------------------------
//  /[locale]/blog — Blog listing
// ---------------------------------------------------------------------------

interface Props {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  return buildPageMetadata({ locale, page: "blog" });
}

/* ── Featured card (first / newest post) ── */
function FeaturedCard({ post, locale }: { post: PostMeta; locale: string }) {
  return (
    <Link
      href={`/${locale}/blog/${post.slug}`}
      className="group block rounded-[2rem] overflow-hidden bg-white shadow-sm hover:shadow-xl transition-shadow duration-300 border border-slate-100 md:grid md:grid-cols-2"
    >
      {/* image */}
      <div className="relative aspect-[16/9] md:aspect-auto bg-warm-white">
        {post.cover ? (
          <Image
            src={post.cover}
            alt={post.title}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 50vw"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <BookOpen size={48} className="text-brand-cyan/40" />
          </div>
        )}
      </div>

      {/* text */}
      <div className="p-8 md:p-10 flex flex-col justify-center">
        <span className="inline-block text-[10px] font-bold text-brand-cyan uppercase tracking-[0.3em] mb-3">
          {post.category}
        </span>
        <h2 className="font-heading text-2xl md:text-3xl font-bold text-brand-blue mb-3 group-hover:text-brand-cyan transition-colors">
          {post.title}
        </h2>
        <p className="text-sm text-slate-500 leading-relaxed mb-4 line-clamp-3">
          {post.excerpt}
        </p>
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <Calendar size={14} /> {post.date}
          </span>
          <span className="flex items-center gap-1">
            <Clock size={14} /> {post.readTime}
          </span>
        </div>
      </div>
    </Link>
  );
}

/* ── Grid card ── */
function BlogCard({ post, locale }: { post: PostMeta; locale: string }) {
  return (
    <Link
      href={`/${locale}/blog/${post.slug}`}
      className="group block rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-xl transition-shadow duration-300 border border-slate-100"
    >
      <div className="relative aspect-[16/9] bg-warm-white">
        {post.cover ? (
          <Image
            src={post.cover}
            alt={post.title}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <BookOpen size={32} className="text-brand-cyan/40" />
          </div>
        )}
      </div>

      <div className="p-8">
        <span className="inline-block text-[10px] font-bold text-brand-cyan uppercase tracking-[0.3em] mb-2">
          {post.category}
        </span>
        <h3 className="font-heading text-xl font-semibold text-brand-blue mb-2 group-hover:text-brand-cyan transition-colors line-clamp-2">
          {post.title}
        </h3>
        <p className="text-sm text-slate-500 leading-relaxed mb-4 line-clamp-2">
          {post.excerpt}
        </p>
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <Calendar size={14} /> {post.date}
          </span>
          <span className="flex items-center gap-1 text-brand-blue group-hover:text-brand-cyan transition-colors">
            Read <ArrowRight size={14} />
          </span>
        </div>
      </div>
    </Link>
  );
}

/* ── Page ── */
export default function BlogListPage() {
  const locale = useLocale();
  const t = useTranslations("blogPage");
  const posts = getAllPosts(locale);

  const featured = posts[0] ?? null;
  const rest = posts.slice(1);

  return (
    <>
      {/* Hero */}
      <section className="bg-warm-white py-24 px-6">
        <div className="mx-auto max-w-7xl text-center">
          <span className="text-xs font-bold text-brand-cyan uppercase tracking-[0.3em] mb-4 block">
            {t("label")}
          </span>
          <h1 className="font-heading text-3xl md:text-5xl font-bold text-brand-blue mb-4">
            {t("title")}
          </h1>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto">
            {t("subtitle")}
          </p>
        </div>
      </section>

      {/* Posts */}
      <section className="bg-white py-24 px-6">
        <div className="mx-auto max-w-7xl space-y-16">
          {/* Featured */}
          {featured && <FeaturedCard post={featured} locale={locale} />}

          {/* Grid */}
          {rest.length > 0 && (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {rest.map((post) => (
                <BlogCard key={post.slug} post={post} locale={locale} />
              ))}
            </div>
          )}

          {posts.length === 0 && (
            <p className="text-center text-slate-400 text-sm py-16">
              {t("noPosts")}
            </p>
          )}
        </div>
      </section>
    </>
  );
}

import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Calendar, Clock, ArrowLeft } from "lucide-react";
import { getPostBySlug, getAllSlugs } from "@/lib/blog";

// ---------------------------------------------------------------------------
//  /[locale]/blog/[slug] — Blog detail
// ---------------------------------------------------------------------------

interface Props {
  params: Promise<{ locale: string; slug: string }>;
}

export async function generateStaticParams() {
  return getAllSlugs().map(({ locale, slug }) => ({ locale, slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, slug } = await params;
  const post = getPostBySlug(locale, slug);
  if (!post) return {};

  const url = `https://homepedia.com.au/${locale}/blog/${slug}`;
  const alt = locale === "en" ? "zh" : "en";

  return {
    title: `${post.title} — Homepedia Blog`,
    description: post.excerpt,
    alternates: {
      canonical: url,
      languages: { [locale]: url, [alt]: `https://homepedia.com.au/${alt}/blog/${slug}` },
    },
    openGraph: {
      title: post.title,
      description: post.excerpt,
      url,
      type: "article",
      images: post.cover
        ? [{ url: `https://homepedia.com.au${post.cover}`, width: 1200, height: 630 }]
        : undefined,
    },
    twitter: { card: "summary_large_image", title: post.title, description: post.excerpt },
  };
}

// ---------------------------------------------------------------------------
//  Minimal Markdown → HTML (zero deps)
// ---------------------------------------------------------------------------
function markdownToHtml(md: string): string {
  let html = md;

  // fenced code blocks
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_m, lang, code) =>
    `<pre class="bg-slate-50 rounded-xl p-4 overflow-x-auto text-sm my-4"><code class="language-${lang}">${esc(code.trim())}</code></pre>`
  );

  // blockquotes
  html = html.replace(/^>\s?(.*)$/gm,
    '<blockquote class="border-l-4 border-brand-cyan pl-4 italic text-slate-500 my-4">$1</blockquote>');

  // images
  html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g,
    '<img src="$2" alt="$1" class="rounded-xl w-full my-6" loading="lazy" />');

  // headings
  html = html.replace(/^### (.+)$/gm, '<h3 class="font-heading text-lg font-semibold text-brand-blue mt-8 mb-3">$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2 class="font-heading text-xl font-semibold text-brand-blue mt-10 mb-4">$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1 class="font-heading text-2xl font-bold text-brand-blue mt-10 mb-4">$1</h1>');

  // hr
  html = html.replace(/^---$/gm, '<hr class="border-slate-100 my-8" />');

  // unordered lists
  html = html.replace(/^[*-] (.+)$/gm, '<li class="ml-4 list-disc text-sm text-slate-500 leading-relaxed">$1</li>');
  // ordered lists
  html = html.replace(/^\d+\. (.+)$/gm, '<li class="ml-4 list-decimal text-sm text-slate-500 leading-relaxed">$1</li>');
  // wrap consecutive <li>
  html = html.replace(/((?:<li class="ml-4 list-disc[^>]*>.*<\/li>\n?)+)/g, '<ul class="my-4 space-y-1">$1</ul>');
  html = html.replace(/((?:<li class="ml-4 list-decimal[^>]*>.*<\/li>\n?)+)/g, '<ol class="my-4 space-y-1">$1</ol>');

  // bold & italic
  html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*(.+?)\*/g, "<em>$1</em>");

  // inline code
  html = html.replace(/`([^`]+)`/g, '<code class="bg-slate-100 px-1.5 py-0.5 rounded text-sm text-brand-blue">$1</code>');

  // links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g,
    '<a href="$2" class="text-brand-blue underline hover:text-brand-cyan" target="_blank" rel="noopener noreferrer">$1</a>');

  // paragraphs
  html = html.split("\n\n").map((block) => {
    const t = block.trim();
    if (!t) return "";
    if (/^</.test(t)) return t;
    return `<p class="text-sm text-slate-500 leading-relaxed my-4">${t.replace(/\n/g, "<br/>")}</p>`;
  }).join("\n");

  return html;
}

function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// ---------------------------------------------------------------------------
//  Page component (async RSC)
// ---------------------------------------------------------------------------
export default async function BlogPostPage({ params }: Props) {
  const { locale, slug } = await params;
  const post = getPostBySlug(locale, slug);
  if (!post) notFound();

  const htmlContent = markdownToHtml(post.content);
  const isZh = locale === "zh";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    datePublished: post.date,
    author: { "@type": "Organization", name: "Homepedia" },
    publisher: { "@type": "Organization", name: "Homepedia" },
    description: post.excerpt,
    inLanguage: locale,
    ...(post.cover && { image: `https://homepedia.com.au${post.cover}` }),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* ── Hero ── */}
      <section className="bg-warm-white py-24 px-6">
        <div className="mx-auto max-w-3xl">
          <Link
            href={`/${locale}/blog`}
            className="inline-flex items-center gap-2 text-sm text-brand-blue hover:text-brand-cyan transition-colors mb-8"
          >
            <ArrowLeft size={16} />
            {isZh ? "返回博客列表" : "Back to Blog"}
          </Link>

          <span className="text-[10px] font-bold text-brand-cyan uppercase tracking-[0.3em] mb-3 block">
            {post.category}
          </span>
          <h1 className="font-heading text-3xl md:text-5xl font-bold text-brand-blue mb-6">
            {post.title}
          </h1>
          <div className="flex items-center gap-4 text-xs text-slate-400">
            <span className="flex items-center gap-1"><Calendar size={14} /> {post.date}</span>
            <span className="flex items-center gap-1"><Clock size={14} /> {post.readTime}</span>
          </div>
        </div>
      </section>

      {/* ── Cover ── */}
      {post.cover && (
        <div className="bg-white px-6">
          <div className="mx-auto max-w-4xl -mt-4">
            <Image src={post.cover} alt={post.title} width={1200} height={630}
              className="rounded-2xl w-full object-cover" priority />
          </div>
        </div>
      )}

      {/* ── Body ── */}
      <section className="bg-white py-16 px-6">
        <article className="mx-auto max-w-prose" dangerouslySetInnerHTML={{ __html: htmlContent }} />
      </section>

      {/* ── Bottom CTA ── */}
      <section className="bg-warm-white py-24 px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-bold text-brand-cyan uppercase tracking-[0.3em] mb-4 block">
            {isZh ? "需要帮助？" : "Need Help?"}
          </span>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-brand-blue mb-4">
            {isZh ? "与我们的 AI 助手聊聊" : "Talk to Our AI Assistant"}
          </h2>
          <p className="text-slate-500 text-sm mb-8">
            {isZh
              ? "我们的 AI 税务助手可以帮助您解答税务问题，整理报税材料。"
              : "Our AI Tax Assistant can help answer your tax questions and organise your return documents."}
          </p>
          <a
            href="https://app.homepedia.com.au"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-brand-gold hover:bg-[#ffaa2b] text-brand-blue font-bold py-4 px-10 rounded-xl shadow-2xl shadow-brand-gold/30 active:scale-95 transition-all"
          >
            {isZh ? "开始使用 AI 助手" : "Start with AI Assistant"}
          </a>
        </div>
      </section>
    </>
  );
}

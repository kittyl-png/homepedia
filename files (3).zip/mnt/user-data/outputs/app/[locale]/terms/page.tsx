import { useTranslations } from "next-intl";
import type { Metadata } from "next";
import { buildPageMetadata } from "@/lib/metadata";

// ---------------------------------------------------------------------------
//  /[locale]/terms — Terms of Service
// ---------------------------------------------------------------------------

interface Props {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  return buildPageMetadata({ locale, page: "terms" });
}

export default function TermsPage() {
  const t = useTranslations("termsPage");

  const sections = [
    "acceptance",
    "servicesDescription",
    "aiAssistantDisclaimer",
    "professionalAdvice",
    "userResponsibilities",
    "limitationOfLiability",
    "privacyLink",
    "changes",
  ] as const;

  return (
    <>
      {/* ── Hero ── */}
      <section className="bg-warm-white py-24 px-6">
        <div className="mx-auto max-w-4xl text-center">
          <span className="text-xs font-bold text-brand-cyan uppercase tracking-[0.3em] mb-4 block">
            {t("label")}
          </span>
          <h1 className="font-heading text-3xl md:text-5xl font-bold text-brand-blue mb-4">
            {t("title")}
          </h1>
          <p className="text-slate-500 text-sm">
            {t("lastUpdated")}
          </p>
        </div>
      </section>

      {/* ── Body ── */}
      <section className="bg-white py-24 px-6">
        <div className="mx-auto max-w-3xl space-y-12">
          <p className="text-sm text-slate-500 leading-relaxed">
            {t("intro")}
          </p>

          {sections.map((key, i) => (
            <article key={key}>
              <span className="text-xs font-bold text-brand-cyan uppercase tracking-[0.3em] mb-3 block">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h2 className="font-heading text-xl font-semibold text-brand-blue mb-3">
                {t(`sections.${key}.title`)}
              </h2>
              <p className="text-sm text-slate-500 leading-relaxed">
                {t(`sections.${key}.body`)}
              </p>
            </article>
          ))}

          <div className="border-t border-slate-100 pt-8">
            <p className="text-xs text-slate-400 leading-relaxed">
              Homepedia Pty Ltd · ABN 44 643 057 354 · Registered Tax Agent TPB
              #26336583 · info@homepedia.com.au
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
